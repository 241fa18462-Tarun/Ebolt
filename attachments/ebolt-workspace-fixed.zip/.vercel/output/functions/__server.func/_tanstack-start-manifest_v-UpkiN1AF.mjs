//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-UpkiN1AF.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-l0bNFf2N.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-l0bNFf2N.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-LO1Y6A4T.js"]
	}
} });
//#endregion
export { tsrStartManifest };
