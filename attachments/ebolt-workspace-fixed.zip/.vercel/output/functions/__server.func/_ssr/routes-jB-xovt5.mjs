import { i as __toESM } from "../_runtime.mjs";
import { L as require_react, v as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Pencil, c as House, i as Plus, l as Eye, o as NotebookText, r as Sparkles, s as LogOut, t as X, u as EyeOff } from "../_libs/lucide-react.mjs";
import { t as create } from "../_libs/zustand.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-jB-xovt5.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var NOTES_KEY = "ebolt_notes";
var REMEMBER_KEY = "ebolt_remember";
var ACCOUNTS_KEY = "ebolt_accounts";
function readNotes() {
	try {
		const raw = JSON.parse(localStorage.getItem(NOTES_KEY) || "[]");
		if (!Array.isArray(raw)) return [];
		return raw.map((n, i) => ({
			id: n.id || `legacy_${i}_${Date.now()}`,
			title: n.title || "Untitled note",
			text: n.text || "",
			updated: n.updated || (/* @__PURE__ */ new Date()).toLocaleString()
		}));
	} catch {
		return [];
	}
}
function writeNotes(notes) {
	localStorage.setItem(NOTES_KEY, JSON.stringify(notes.slice(0, 80)));
}
function readAccounts() {
	try {
		return JSON.parse(localStorage.getItem(ACCOUNTS_KEY) || "{}") || {};
	} catch {
		return {};
	}
}
function writeAccounts(accounts) {
	localStorage.setItem(ACCOUNTS_KEY, JSON.stringify(accounts));
}
function displayName(email, fullName) {
	if (fullName?.trim()) return fullName.trim();
	return email.split("@")[0].replace(/[._-]+/g, " ").replace(/\b\w/g, (c) => c.toUpperCase());
}
var toastTimer;
var useEbolt = create((set, get) => ({
	user: null,
	page: "home",
	notes: typeof window === "undefined" ? [] : readNotes(),
	currentNoteId: null,
	draftTitle: "Untitled note",
	draftText: "Start writing your next idea...",
	toast: null,
	chat: [{
		role: "bot",
		text: "Hi! I’m your Ebolt AI Chat Bot. Tell me what you want to write, organize or improve."
	}],
	login: (user) => {
		set({
			user,
			page: "home",
			notes: readNotes(),
			currentNoteId: null,
			draftTitle: "Untitled note",
			draftText: "Start writing your next idea..."
		});
	},
	logout: () => {
		localStorage.removeItem(REMEMBER_KEY);
		set({
			user: null,
			page: "home",
			currentNoteId: null,
			draftTitle: "Untitled note",
			draftText: "Start writing your next idea..."
		});
	},
	go: (page) => set({ page }),
	setDraftTitle: (draftTitle) => set({ draftTitle }),
	setDraftText: (draftText) => set({ draftText }),
	newNote: () => set({
		currentNoteId: null,
		draftTitle: "Untitled note",
		draftText: "Start writing here...\n\nAdd your development notes, ideas, commands or documentation.",
		page: "new"
	}),
	saveNote: () => {
		const { draftTitle, draftText, currentNoteId, notes } = get();
		const title = draftTitle.trim() || "Untitled note";
		const text = draftText.trim();
		const now = (/* @__PURE__ */ new Date()).toLocaleString();
		let next = [...notes];
		let id = currentNoteId;
		if (id) {
			const idx = next.findIndex((n) => n.id === id);
			if (idx >= 0) next[idx] = {
				...next[idx],
				title,
				text,
				updated: now
			};
			else {
				id = `note_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
				next.unshift({
					id,
					title,
					text,
					updated: now
				});
			}
		} else {
			id = `note_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
			next.unshift({
				id,
				title,
				text,
				updated: now
			});
		}
		writeNotes(next);
		set({
			notes: next,
			currentNoteId: id,
			draftTitle: title,
			draftText: text || draftText
		});
		get().showToast("Note saved");
	},
	loadNote: (id) => {
		const n = get().notes.find((x) => x.id === id);
		if (!n) return;
		set({
			currentNoteId: n.id,
			draftTitle: n.title,
			draftText: n.text,
			page: "new"
		});
		get().showToast("Note opened");
	},
	deleteNote: (id) => {
		const { notes, currentNoteId } = get();
		const next = notes.filter((n) => n.id !== id);
		writeNotes(next);
		if (currentNoteId === id) set({
			notes: next,
			currentNoteId: null,
			draftTitle: "Untitled note",
			draftText: "Start writing here...\n\nAdd your development notes, ideas, commands or documentation."
		});
		else set({ notes: next });
		get().showToast("Note deleted");
	},
	renameDraft: (title) => set({ draftTitle: title.trim() || "Untitled note" }),
	showToast: (msg) => {
		if (toastTimer) clearTimeout(toastTimer);
		set({ toast: msg });
		toastTimer = setTimeout(() => set({ toast: null }), 1800);
	},
	sendChat: (text) => {
		const trimmed = text.trim();
		if (!trimmed) return;
		const reply = "I can help you shape that idea. Try putting the main goal, the next action, and any important details into your Blackbox note.";
		set({ chat: [
			...get().chat,
			{
				role: "user",
				text: trimmed
			},
			{
				role: "bot",
				text: reply
			}
		] });
	}
}));
function tryRememberedUser() {
	try {
		return JSON.parse(localStorage.getItem(REMEMBER_KEY) || "null");
	} catch {
		return null;
	}
}
function rememberUser(user) {
	localStorage.setItem(REMEMBER_KEY, JSON.stringify(user));
}
function validEmail(email) {
	return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}
function LoginScreen() {
	const login = useEbolt((s) => s.login);
	const [signup, setSignup] = (0, import_react.useState)(false);
	const [showPass, setShowPass] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)("");
	const [email, setEmail] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [fullName, setFullName] = (0, import_react.useState)("");
	const [confirm, setConfirm] = (0, import_react.useState)("");
	const [remember, setRemember] = (0, import_react.useState)(false);
	function onSubmit(e) {
		e.preventDefault();
		const em = email.trim().toLowerCase();
		if (!validEmail(em)) {
			setError("Please enter a valid email address.");
			return;
		}
		const accounts = readAccounts();
		if (signup) {
			if (!fullName.trim()) {
				setError("Please enter your full name.");
				return;
			}
			if (!password) {
				setError("Please enter a password.");
				return;
			}
			if (password !== confirm) {
				setError("Passwords do not match.");
				return;
			}
			if (accounts[em]) {
				setError("That account already exists. Please sign in.");
				return;
			}
			const user = {
				email: em,
				password,
				fullName: fullName.trim()
			};
			accounts[em] = user;
			writeAccounts(accounts);
			if (remember) rememberUser(user);
			login(user);
			return;
		}
		const account = accounts[em];
		const expected = account ? account.password : em.split("@")[0];
		if (password !== expected) {
			setError("Incorrect password. For the demo, use the text before @ as the password.");
			return;
		}
		const user = account || {
			email: em,
			password: expected,
			fullName: displayName(em)
		};
		if (remember) rememberUser(user);
		login(user);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "login-sky relative flex min-h-screen items-center justify-center overflow-hidden px-4 py-8",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative grid w-full max-w-[1050px] overflow-hidden rounded-[34px] border border-white/15 bg-linear-to-br from-[#071923]/98 to-[#0a242f]/98 shadow-[0_30px_80px_rgb(4_35_48_/_0.3)] md:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "relative z-2 px-7 py-10 sm:px-12",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-14 flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: "/ebolt-logo.png",
							alt: "",
							className: "size-[42px] rounded-full border-2 border-white/70 object-cover"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[15px] font-extrabold tracking-[1.8px]",
							children: "EBOLT"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-8",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mb-2 font-extrabold tracking-[2px] text-sky",
							children: signup ? "CREATE ACCOUNT" : "WELCOME BACK!"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[13px] text-muted",
							children: signup ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
								"Already have an account?",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "font-bold text-sky",
									onClick: () => setSignup(false),
									children: "Sign in"
								})
							] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
								"Don't have an account?",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "font-bold text-sky",
									onClick: () => setSignup(true),
									children: "Sign up"
								})
							] })
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						onSubmit,
						className: "space-y-5",
						children: [
							signup && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "field-in block",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mb-2 block text-[12px] font-bold tracking-[1.2px]",
									children: "FULL NAME"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: "h-12 w-full rounded-full border border-sky/70 bg-white/5 px-4 text-cream outline-none placeholder:text-dim focus:border-white",
									placeholder: "Your full name",
									value: fullName,
									onChange: (e) => setFullName(e.target.value)
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "field-in block",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mb-2 block text-[12px] font-bold tracking-[1.2px]",
									children: "USERNAME"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "email",
									required: true,
									className: "h-12 w-full rounded-full border border-sky/70 bg-white/5 px-4 text-cream outline-none placeholder:text-dim focus:border-white",
									placeholder: "example@gmail.com",
									value: email,
									onChange: (e) => setEmail(e.target.value)
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "field-in block",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mb-2 block text-[12px] font-bold tracking-[1.2px]",
									children: "PASSWORD"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "relative block",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: showPass ? "text" : "password",
										required: true,
										className: "h-12 w-full rounded-full border border-sky/70 bg-white/5 px-4 pr-12 text-cream outline-none placeholder:text-dim focus:border-white",
										placeholder: "••••••••",
										value: password,
										onChange: (e) => setPassword(e.target.value)
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "absolute top-1/2 right-3 grid size-9 -translate-y-1/2 place-items-center rounded-full text-sky",
										onClick: () => setShowPass((v) => !v),
										"aria-label": showPass ? "Hide password" : "Show password",
										children: showPass ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EyeOff, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "size-4" })
									})]
								})]
							}),
							signup && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "field-in block",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mb-2 block text-[12px] font-bold tracking-[1.2px]",
									children: "CONFIRM PASSWORD"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: showPass ? "text" : "password",
									className: "h-12 w-full rounded-full border border-sky/70 bg-white/5 px-4 text-cream outline-none placeholder:text-dim",
									placeholder: "Repeat your password",
									value: confirm,
									onChange: (e) => setConfirm(e.target.value)
								})]
							}),
							!signup && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between text-[10px] text-muted",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "checkbox",
										className: "accent-sky",
										checked: remember,
										onChange: (e) => setRemember(e.target.checked)
									}), "Remember me"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-bold text-sky",
									children: "Forgot password?"
								})]
							}),
							error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-danger",
								children: error
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "submit",
								className: "pill pill-primary h-12 w-full text-[11px] tracking-[1px]",
								children: signup ? "CREATE ACCOUNT" : "SIGN IN"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-center text-[10px] text-dim",
								children: "Demo: use the text before @ as the password (e.g. ravi@gmail.com / ravi)"
							})
						]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "relative hidden min-h-[420px] items-center justify-center md:flex",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: "/ebolt-logo.png",
					alt: "",
					className: "size-[280px] rounded-full border-[10px] border-white object-cover shadow-[0_25px_70px_rgb(0_0_0_/_0.34)]"
				})
			})]
		})
	});
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function Orb({ size = 42, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("relative inline-grid shrink-0 place-items-center overflow-hidden rounded-full orb-ring", className),
		style: {
			width: size,
			height: size
		},
		"aria-hidden": "true",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
			className: "h-full w-full scale-110 object-cover",
			src: "/orb.mp4",
			autoPlay: true,
			loop: true,
			muted: true,
			playsInline: true,
			preload: "auto"
		})
	});
}
var NAV = [
	{
		id: "home",
		label: "Home",
		icon: House
	},
	{
		id: "new",
		label: "New Note",
		icon: Plus
	},
	{
		id: "saved",
		label: "Saved Note",
		icon: NotebookText
	},
	{
		id: "chat",
		label: "AI Chat Bot",
		icon: Sparkles
	}
];
function Workspace() {
	const user = useEbolt((s) => s.user);
	const page = useEbolt((s) => s.page);
	const go = useEbolt((s) => s.go);
	const logout = useEbolt((s) => s.logout);
	const toast = useEbolt((s) => s.toast);
	const name = displayName(user.email, user.fullName);
	const initial = name.charAt(0).toUpperCase();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "app-bg min-h-screen text-cream",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid min-h-screen lg:grid-cols-[205px_1fr]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
					className: "sticky top-0 z-20 hidden h-screen flex-col border-r border-sky/15 bg-ink/94 px-3 py-5 backdrop-blur-xl lg:flex",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-5 flex items-center gap-3 px-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: "/ebolt-logo.png",
								alt: "",
								className: "size-10 rounded-full border-2 border-white/70 object-cover"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[15px] font-extrabold tracking-[1.8px]",
								children: "EBOLT"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-4 flex items-center gap-2.5 rounded-2xl border border-sky/15 bg-white/5 p-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid size-9 place-items-center rounded-full bg-linear-to-br from-ice to-sky text-xs font-extrabold text-navy",
								children: initial
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
									className: "block truncate text-[11px]",
									children: name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", {
									className: "block truncate text-[8px] text-muted",
									children: user.email
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
							className: "grid gap-1.5",
							"aria-label": "Ebolt navigation",
							children: NAV.map((item) => {
								const Icon = item.icon;
								const active = page === item.id;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									onClick: () => item.id === "new" ? useEbolt.getState().newNote() : go(item.id),
									className: cn("flex h-11 items-center gap-2.5 rounded-[13px] px-3 text-left text-[10px] font-bold tracking-[0.55px] text-muted transition", active && "border border-sky/20 bg-sky/10 text-cream"),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: cn("grid size-6 place-items-center rounded-lg bg-sky/10 text-sky", active && "bg-linear-to-br from-sky-2 to-ice text-navy"),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-3.5" })
									}), item.label]
								}, item.id);
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-auto px-1 text-[8px] leading-relaxed text-dim",
							children: ["BUILD • WRITE • IMPROVE", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								className: "mt-2 flex h-9 w-full items-center justify-center gap-2 rounded-[10px] border border-white/10 bg-white/5 text-[9px] font-bold tracking-wide text-muted",
								onClick: logout,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { className: "size-3" }), " LOG OUT"]
							})]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
					className: "min-w-0 pb-20 lg:pb-0",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto max-w-[1400px] px-4 py-5 sm:px-8 sm:py-6",
						children: [
							page === "home" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HomeView, { name }),
							page === "saved" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SavedView, {}),
							page === "new" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EditorView, {}),
							page === "chat" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChatView, {})
						]
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "fixed inset-x-0 bottom-0 z-30 grid grid-cols-4 gap-1 border-t border-sky/15 bg-ink/95 p-2 backdrop-blur lg:hidden",
				children: NAV.map((item) => {
					const Icon = item.icon;
					const active = page === item.id;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => item.id === "new" ? useEbolt.getState().newNote() : go(item.id),
						className: cn("flex h-12 flex-col items-center justify-center gap-0.5 rounded-xl text-[8px] font-bold text-muted", active && "bg-sky/10 text-cream"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" }), item.label]
					}, item.id);
				})
			}),
			toast && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed right-5 bottom-24 z-50 rounded-xl border border-sky/25 bg-navy px-4 py-3 text-[10px] font-semibold text-ice shadow-xl lg:bottom-6",
				children: toast
			})
		]
	});
}
function HomeView({ name }) {
	const go = useEbolt((s) => s.go);
	const saveNote = useEbolt((s) => s.saveNote);
	const draftTitle = useEbolt((s) => s.draftTitle);
	const draftText = useEbolt((s) => s.draftText);
	const setDraftTitle = useEbolt((s) => s.setDraftTitle);
	const setDraftText = useEbolt((s) => s.setDraftText);
	const notes = useEbolt((s) => s.notes);
	const now = (0, import_react.useMemo)(() => /* @__PURE__ */ new Date(), []);
	const day = now.toLocaleDateString(void 0, { weekday: "long" });
	const date = now.toLocaleDateString(void 0, {
		day: "numeric",
		month: "long",
		year: "numeric"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "page-in",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-5 flex flex-col justify-between gap-4 sm:flex-row sm:items-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
					className: "text-[25px] tracking-tight",
					children: ["Hey, ", name]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-[11px] text-dim italic",
					children: "Let’s make progress today!"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex min-w-[210px] items-center gap-3 rounded-2xl border border-sky/15 bg-navy/80 px-3 py-2.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Orb, { size: 40 }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-right",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
							className: "block text-[11px]",
							children: day
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-0.5 block text-[9px] text-muted",
							children: date
						})]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "hero-dots relative flex min-h-[360px] items-center justify-center overflow-hidden rounded-[28px] border border-sky/15 bg-linear-to-br from-navy/92 to-navy-2/85 text-center",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative z-2 max-w-[780px] px-5 py-10",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mb-4 text-[9px] font-extrabold tracking-[2.8px] text-sky",
							children: "BLACKBOX / EBOLT WORKSPACE"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
							className: "font-display text-[clamp(36px,5.6vw,64px)] leading-[1.08] font-semibold tracking-tight text-transparent bg-clip-text bg-linear-to-r from-cream via-sky to-ice",
							children: [
								"Explore your",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
								"ideas clearly."
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mx-auto mt-5 max-w-[650px] text-[12px] leading-7 text-muted",
							children: "Your focused Blackbox workspace for writing, organizing, saving and improving ideas without the extra dashboard clutter."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-5 flex justify-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								className: "pill pill-primary",
								onClick: () => useEbolt.getState().newNote(),
								children: "OPEN BLACKBOX"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								className: "pill",
								onClick: () => go("saved"),
								children: "VIEW SAVED NOTES"
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-7",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-4 flex flex-col justify-between gap-3 sm:flex-row sm:items-end",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-[19px]",
						children: "Blackbox quick workspace"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-[9px] text-dim",
						children: [
							"Write directly from Home. ",
							notes.length,
							" saved notes."
						]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "pill",
							onClick: () => go("saved"),
							children: "Saved Note"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "pill pill-primary",
							onClick: () => useEbolt.getState().newNote(),
							children: "New"
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 lg:grid-cols-[minmax(0,1fr)_300px]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "overflow-hidden rounded-[18px] border border-sky/20 bg-[#02080c]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex h-11 items-center justify-between border-b border-sky/10 px-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex gap-1",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { className: "size-1.5 rounded-full bg-dim" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { className: "size-1.5 rounded-full bg-dim" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { className: "size-1.5 rounded-full bg-dim" })
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: "h-7 w-40 rounded-md border border-sky/20 bg-white/5 px-2 font-mono text-[9px] text-ice outline-none",
									value: draftTitle,
									onChange: (e) => setDraftTitle(e.target.value),
									"aria-label": "Note title"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									className: "pill",
									onClick: saveNote,
									children: "Save"
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							className: "min-h-[280px] w-full resize-none border-0 bg-transparent p-4 font-mono text-[12px] leading-7 text-ice outline-none",
							value: draftText,
							onChange: (e) => setDraftText(e.target.value)
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
						className: "glass-card rounded-[18px] p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "mb-3 text-[11px]",
							children: "Blackbox quotes"
						}), [
							"Build ideas into something real.",
							"Turn a rough idea into a clear task.",
							"Small steps create big progress.",
							"Write it, save it, improve it."
						].map((q) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "border-b border-sky/10 py-3 font-mono text-[10px] text-dim",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
									className: "text-sky",
									children: "“"
								}),
								" ",
								q
							]
						}, q))]
					})]
				})]
			})
		]
	});
}
function SavedView() {
	const notes = useEbolt((s) => s.notes);
	const loadNote = useEbolt((s) => s.loadNote);
	const deleteNote = useEbolt((s) => s.deleteNote);
	const newNote = useEbolt((s) => s.newNote);
	function onDelete(id, title) {
		if (!confirm(`Delete "${title}"? This cannot be undone.`)) return;
		deleteNote(id);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "page-in",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-4 flex flex-col justify-between gap-3 sm:flex-row sm:items-end",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-[19px]",
				children: "Saved Note"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-[9px] text-dim",
				children: "Open, continue, edit and manage your saved Blackbox notes."
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				className: "pill pill-primary",
				onClick: newNote,
				children: "New note"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-3 sm:grid-cols-2 xl:grid-cols-3",
			children: [notes.map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "glass-card relative min-h-[165px] cursor-pointer rounded-[18px] p-4 pr-12 transition hover:-translate-y-0.5 hover:border-sky/30",
				onClick: () => loadNote(n.id),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "absolute top-3 right-3 grid size-[30px] place-items-center rounded-[9px] border border-sky/20 bg-white/5 text-muted hover:border-danger/40 hover:bg-red-500/15 hover:text-danger",
						"aria-label": `Delete ${n.title}`,
						onClick: (e) => {
							e.stopPropagation();
							onDelete(n.id, n.title);
						},
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3.5" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "mb-2 pr-4 text-[13px]",
						children: n.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "line-clamp-4 text-[10px] leading-5 text-dim",
						children: n.text || "Empty note"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", {
							className: "text-[8px] text-dim",
							children: n.updated
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "pill inline-flex h-8 items-center gap-1",
							onClick: (e) => {
								e.stopPropagation();
								loadNote(n.id);
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "size-3" }), " Edit"]
						})]
					})
				]
			}, n.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: newNote,
				className: "glass-card flex min-h-[165px] flex-col items-center justify-center gap-3 rounded-[18px] border-dashed border-sky/30 text-sky transition hover:border-sky/60 hover:bg-sky/5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "grid size-12 place-items-center rounded-full border border-sky/30 text-2xl",
					children: "+"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-[11px] font-bold tracking-wide",
					children: "New note"
				})]
			})]
		})]
	});
}
function EditorView() {
	const currentNoteId = useEbolt((s) => s.currentNoteId);
	const draftTitle = useEbolt((s) => s.draftTitle);
	const draftText = useEbolt((s) => s.draftText);
	const setDraftTitle = useEbolt((s) => s.setDraftTitle);
	const setDraftText = useEbolt((s) => s.setDraftText);
	const saveNote = useEbolt((s) => s.saveNote);
	const newNote = useEbolt((s) => s.newNote);
	const renameDraft = useEbolt((s) => s.renameDraft);
	const go = useEbolt((s) => s.go);
	const editing = Boolean(currentNoteId);
	function rename() {
		const next = prompt("Name this note", draftTitle);
		if (next && next.trim()) renameDraft(next);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "page-in",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-4 flex flex-col justify-between gap-3 sm:flex-row sm:items-end",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-[19px]",
				children: editing ? "Edit note" : "New Blackbox"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-[9px] text-dim",
				children: editing ? "Update this note and save. Delete from Saved Note." : "Create a new text, rename it and save it as a note."
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "pill",
						onClick: newNote,
						children: "Clear"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "pill",
						onClick: () => go("saved"),
						children: "All notes"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "pill pill-primary",
						onClick: saveNote,
						children: editing ? "Update note" : "Save note"
					})
				]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-3 lg:grid-cols-[1fr_280px]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "glass-card rounded-[18px] p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "mb-3 h-11 w-full rounded-xl border border-sky/20 bg-white/5 px-3.5 text-[12px] font-bold text-cream outline-none",
						value: draftTitle,
						onChange: (e) => setDraftTitle(e.target.value),
						placeholder: "Note title"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						className: "min-h-[380px] w-full resize-y rounded-xl border-0 bg-transparent p-2 font-mono text-[12px] leading-7 text-ice outline-none",
						value: draftText,
						onChange: (e) => setDraftText(e.target.value)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "pill",
							onClick: rename,
							children: "Rename"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "pill pill-primary",
							onClick: saveNote,
							children: editing ? "Update" : "Save"
						})]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "glass-card rounded-[18px] p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "mb-3 text-[12px]",
					children: "Blackbox tools"
				}), [
					"Write without leaving the workspace.",
					"Rename the note whenever you need.",
					"Save many notes — each keeps its own id.",
					"Edit or delete any card from Saved Note."
				].map((t, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "border-b border-sky/10 py-3 text-[9px] text-muted",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("b", {
							className: "text-sky",
							children: ["0", i + 1]
						}),
						" ",
						t
					]
				}, t))]
			})]
		})]
	});
}
function ChatView() {
	const chat = useEbolt((s) => s.chat);
	const sendChat = useEbolt((s) => s.sendChat);
	const [value, setValue] = (0, import_react.useState)("");
	const box = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		box.current?.scrollTo({ top: box.current.scrollHeight });
	}, [chat.length]);
	function onSubmit(e) {
		e.preventDefault();
		sendChat(value);
		setValue("");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "page-in",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-[19px]",
				children: "AI Chat Bot"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-[9px] text-dim",
				children: "Ask the Ebolt assistant about your notes, ideas and workflow."
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "glass-card flex min-h-[620px] flex-col overflow-hidden rounded-[20px]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3 border-b border-sky/10 px-4 py-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: "/ebolt-logo.png",
						alt: "",
						className: "size-10 rounded-xl object-cover"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
						className: "text-[12px]",
						children: "Ebolt AI Chat Bot"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mt-1 block text-[8px] text-dim",
						children: "Ready to help with your Blackbox workspace"
					})] })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					ref: box,
					className: "flex flex-1 flex-col gap-3 overflow-auto p-5",
					children: chat.map((m, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: cn("max-w-[75%] rounded-[15px] px-3.5 py-3 text-[10px] leading-5", m.role === "bot" ? "self-start border border-sky/10 bg-sky/10 text-ice" : "self-end bg-linear-to-r from-sky-2 to-ice text-navy"),
						children: m.text
					}, i))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "flex gap-2 border-t border-sky/10 p-3",
					onSubmit,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "h-10 flex-1 rounded-xl border border-sky/20 bg-white/5 px-3 text-cream outline-none",
						placeholder: "Ask something about your workspace...",
						value,
						onChange: (e) => setValue(e.target.value)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "pill pill-primary h-10",
						type: "submit",
						children: "SEND"
					})]
				})
			]
		})]
	});
}
function Home() {
	const user = useEbolt((s) => s.user);
	const login = useEbolt((s) => s.login);
	(0, import_react.useEffect)(() => {
		if (user) return;
		const remembered = tryRememberedUser();
		if (remembered) login(remembered);
	}, [user, login]);
	if (!user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoginScreen, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Workspace, {});
}
//#endregion
export { Home as component };
