import { FormEvent, useState } from "react";
import { Eye, EyeOff } from "lucide-react";
import {
  displayName,
  readAccounts,
  rememberUser,
  useEbolt,
  writeAccounts,
} from "@/lib/ebolt-store";

function validEmail(email: string) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

export function LoginScreen() {
  const login = useEbolt((s) => s.login);
  const [signup, setSignup] = useState(false);
  const [showPass, setShowPass] = useState(false);
  const [error, setError] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [fullName, setFullName] = useState("");
  const [confirm, setConfirm] = useState("");
  const [remember, setRemember] = useState(false);

  function onSubmit(e: FormEvent) {
    e.preventDefault();
    const em = email.trim().toLowerCase();
    if (!validEmail(em)) {
      setError("Please enter a valid email address.");
      return;
    }
    const accounts = readAccounts();
    if (signup) {
      if (!fullName.trim()) {
        setError("Please enter your full name.");
        return;
      }
      if (!password) {
        setError("Please enter a password.");
        return;
      }
      if (password !== confirm) {
        setError("Passwords do not match.");
        return;
      }
      if (accounts[em]) {
        setError("That account already exists. Please sign in.");
        return;
      }
      const user = { email: em, password, fullName: fullName.trim() };
      accounts[em] = user;
      writeAccounts(accounts);
      if (remember) rememberUser(user);
      login(user);
      return;
    }
    const account = accounts[em];
    const expected = account ? account.password : em.split("@")[0];
    if (password !== expected) {
      setError("Incorrect password. For the demo, use the text before @ as the password.");
      return;
    }
    const user = account || { email: em, password: expected, fullName: displayName(em) };
    if (remember) rememberUser(user);
    login(user);
  }

  return (
    <div className="login-sky relative flex min-h-screen items-center justify-center overflow-hidden px-4 py-8">
      <div className="relative grid w-full max-w-[1050px] overflow-hidden rounded-[34px] border border-white/15 bg-linear-to-br from-[#071923]/98 to-[#0a242f]/98 shadow-[0_30px_80px_rgb(4_35_48_/_0.3)] md:grid-cols-2">
        <section className="relative z-2 px-7 py-10 sm:px-12">
          <div className="mb-14 flex items-center gap-3">
            <img
              src="/ebolt-logo.png"
              alt=""
              className="size-[42px] rounded-full border-2 border-white/70 object-cover"
            />
            <span className="text-[15px] font-extrabold tracking-[1.8px]">EBOLT</span>
          </div>
          <div className="mb-8">
            <h1 className="mb-2 font-extrabold tracking-[2px] text-sky">
              {signup ? "CREATE ACCOUNT" : "WELCOME BACK!"}
            </h1>
            <p className="text-[13px] text-muted">
              {signup ? (
                <>
                  Already have an account?{" "}
                  <button type="button" className="font-bold text-sky" onClick={() => setSignup(false)}>
                    Sign in
                  </button>
                </>
              ) : (
                <>
                  Don't have an account?{" "}
                  <button type="button" className="font-bold text-sky" onClick={() => setSignup(true)}>
                    Sign up
                  </button>
                </>
              )}
            </p>
          </div>
          <form onSubmit={onSubmit} className="space-y-5">
            {signup && (
              <label className="field-in block">
                <span className="mb-2 block text-[12px] font-bold tracking-[1.2px]">FULL NAME</span>
                <input
                  className="h-12 w-full rounded-full border border-sky/70 bg-white/5 px-4 text-cream outline-none placeholder:text-dim focus:border-white"
                  placeholder="Your full name"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                />
              </label>
            )}
            <label className="field-in block">
              <span className="mb-2 block text-[12px] font-bold tracking-[1.2px]">USERNAME</span>
              <input
                type="email"
                required
                className="h-12 w-full rounded-full border border-sky/70 bg-white/5 px-4 text-cream outline-none placeholder:text-dim focus:border-white"
                placeholder="example@gmail.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </label>
            <label className="field-in block">
              <span className="mb-2 block text-[12px] font-bold tracking-[1.2px]">PASSWORD</span>
              <span className="relative block">
                <input
                  type={showPass ? "text" : "password"}
                  required
                  className="h-12 w-full rounded-full border border-sky/70 bg-white/5 px-4 pr-12 text-cream outline-none placeholder:text-dim focus:border-white"
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                />
                <button
                  type="button"
                  className="absolute top-1/2 right-3 grid size-9 -translate-y-1/2 place-items-center rounded-full text-sky"
                  onClick={() => setShowPass((v) => !v)}
                  aria-label={showPass ? "Hide password" : "Show password"}
                >
                  {showPass ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
                </button>
              </span>
            </label>
            {signup && (
              <label className="field-in block">
                <span className="mb-2 block text-[12px] font-bold tracking-[1.2px]">CONFIRM PASSWORD</span>
                <input
                  type={showPass ? "text" : "password"}
                  className="h-12 w-full rounded-full border border-sky/70 bg-white/5 px-4 text-cream outline-none placeholder:text-dim"
                  placeholder="Repeat your password"
                  value={confirm}
                  onChange={(e) => setConfirm(e.target.value)}
                />
              </label>
            )}
            {!signup && (
              <div className="flex items-center justify-between text-[10px] text-muted">
                <label className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    className="accent-sky"
                    checked={remember}
                    onChange={(e) => setRemember(e.target.checked)}
                  />
                  Remember me
                </label>
                <span className="font-bold text-sky">Forgot password?</span>
              </div>
            )}
            {error && <p className="text-xs text-danger">{error}</p>}
            <button type="submit" className="pill pill-primary h-12 w-full text-[11px] tracking-[1px]">
              {signup ? "CREATE ACCOUNT" : "SIGN IN"}
            </button>
            <p className="text-center text-[10px] text-dim">
              Demo: use the text before @ as the password (e.g. ravi@gmail.com / ravi)
            </p>
          </form>
        </section>
        <section className="relative hidden min-h-[420px] items-center justify-center md:flex">
          <img
            src="/ebolt-logo.png"
            alt=""
            className="size-[280px] rounded-full border-[10px] border-white object-cover shadow-[0_25px_70px_rgb(0_0_0_/_0.34)]"
          />
        </section>
      </div>
    </div>
  );
}
