import { FormEvent, useEffect, useMemo, useRef, useState } from "react";
import {
  Copy,
  FileText,
  Home,
  LogOut,
  NotebookText,
  Pencil,
  Plus,
  Search,
  Sparkles,
  Trash2,
  X,
} from "lucide-react";
import { cn } from "@/lib/cn";
import {
  displayName,
  formatWhen,
  selectDirty,
  sortNotes,
  useEbolt,
  wordCount,
  type EboltPage,
  type Note,
  type SortKey,
} from "@/lib/ebolt-store";
import { AuroraBackdrop } from "./aurora";
import { ConfirmDialog, PromptDialog } from "./dialog";
import { Orb } from "./orb";

const NAV: { id: EboltPage; label: string; icon: typeof Home }[] = [
  { id: "home", label: "Home", icon: Home },
  { id: "new", label: "Editor", icon: Plus },
  { id: "saved", label: "Notes", icon: NotebookText },
  { id: "chat", label: "Assistant", icon: Sparkles },
];

export function Workspace() {
  const user = useEbolt((s) => s.user);
  const page = useEbolt((s) => s.page);
  const go = useEbolt((s) => s.go);
  const logout = useEbolt((s) => s.logout);
  const hydrateNotes = useEbolt((s) => s.hydrateNotes);
  const newNote = useEbolt((s) => s.newNote);
  const saveNote = useEbolt((s) => s.saveNote);
  const [confirmLogout, setConfirmLogout] = useState(false);

  // Notes are read from storage here rather than in the store's initial state,
  // so the server render and the first client render always agree.
  useEffect(() => {
    hydrateNotes();
  }, [hydrateNotes]);

  // Ctrl/Cmd+S saves from anywhere in the workspace.
  useEffect(() => {
    function onKeyDown(e: KeyboardEvent) {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "s") {
        e.preventDefault();
        saveNote();
      }
    }
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [saveNote]);

  if (!user) return null;
  const name = displayName(user.email, user.fullName);
  const initial = name.charAt(0).toUpperCase();

  return (
    <div className="app-bg min-h-screen text-cream">
      <div className="grid min-h-screen lg:grid-cols-[228px_1fr]">
        <aside className="sticky top-0 z-20 hidden h-screen flex-col border-r border-sky/12 bg-ink/94 px-3.5 py-6 backdrop-blur-xl lg:flex">
          <div className="mb-6 flex items-center gap-3 px-1.5">
            <img src="/ebolt-logo.png" alt="" className="size-10 rounded-full border border-white/50 object-cover" />
            <span className="text-[15px] font-bold tracking-[3px]">Ebolt</span>
          </div>

          <div className="mb-5 flex items-center gap-2.5 rounded-2xl border border-sky/12 bg-white/4 p-3">
            <div className="grid size-9 shrink-0 place-items-center rounded-full bg-linear-to-br from-ice to-sky text-[12px] font-bold text-navy">
              {initial}
            </div>
            <div className="min-w-0">
              <b className="block truncate text-[12px] font-semibold">{name}</b>
              <small className="block truncate text-[10px] text-dim">{user.email}</small>
            </div>
          </div>

          <nav className="grid gap-1" aria-label="Workspace sections">
            {NAV.map((item) => {
              const Icon = item.icon;
              const active = page === item.id;
              return (
                <button
                  key={item.id}
                  aria-current={active ? "page" : undefined}
                  onClick={() => (item.id === "new" ? newNote() : go(item.id))}
                  className={cn(
                    "flex h-11 items-center gap-3 rounded-[13px] px-3 text-left text-[12px] font-medium text-muted transition-colors hover:text-cream",
                    active && "bg-sky/10 text-cream",
                  )}
                >
                  <span
                    className={cn(
                      "grid size-7 shrink-0 place-items-center rounded-lg bg-sky/10 text-sky transition-colors",
                      active && "bg-linear-to-br from-sky-2 to-ice text-navy",
                    )}
                  >
                    <Icon className="size-3.5" />
                  </span>
                  {item.label}
                </button>
              );
            })}
          </nav>

          <div className="mt-auto">
            <NoteMeter />
            <button
              className="mt-3 flex h-10 w-full items-center justify-center gap-2 rounded-xl border border-white/8 bg-white/4 text-[11px] font-medium text-muted transition-colors hover:border-white/20 hover:text-cream"
              onClick={() => setConfirmLogout(true)}
            >
              <LogOut className="size-3.5" /> Sign out
            </button>
          </div>
        </aside>

        <main className="min-w-0 pb-24 lg:pb-0">
          <div className="mx-auto max-w-[1360px] px-4 py-5 sm:px-8 sm:py-7">
            {page === "home" && <HomeView name={name} />}
            {page === "saved" && <SavedView />}
            {page === "new" && <EditorView />}
            {page === "chat" && <ChatView />}
          </div>
        </main>
      </div>

      <nav
        className="fixed inset-x-0 bottom-0 z-30 grid grid-cols-4 gap-1 border-t border-sky/12 bg-ink/96 p-2 pb-[max(0.5rem,env(safe-area-inset-bottom))] backdrop-blur lg:hidden"
        aria-label="Workspace sections"
      >
        {NAV.map((item) => {
          const Icon = item.icon;
          const active = page === item.id;
          return (
            <button
              key={item.id}
              aria-current={active ? "page" : undefined}
              onClick={() => (item.id === "new" ? newNote() : go(item.id))}
              className={cn(
                "flex h-12 flex-col items-center justify-center gap-1 rounded-xl text-[10px] font-medium text-muted",
                active && "bg-sky/10 text-cream",
              )}
            >
              <Icon className="size-4" />
              {item.label}
            </button>
          );
        })}
      </nav>

      <ToastHost />

      <ConfirmDialog
        open={confirmLogout}
        title="Sign out of Ebolt?"
        description="Your saved notes stay on this device. Unsaved editor changes are lost."
        confirmLabel="Sign out"
        onConfirm={logout}
        onClose={() => setConfirmLogout(false)}
      />
    </div>
  );
}

function NoteMeter() {
  const notes = useEbolt((s) => s.notes);
  const words = useMemo(() => notes.reduce((sum, n) => sum + wordCount(n.text), 0), [notes]);
  return (
    <div className="rounded-xl border border-sky/12 bg-white/3 px-3 py-2.5">
      <div className="flex items-baseline justify-between">
        <span className="text-[19px] font-semibold text-cream tabular-nums">{notes.length}</span>
        <span className="text-[10px] text-dim">{notes.length === 1 ? "note" : "notes"}</span>
      </div>
      <div className="mt-1 text-[10px] text-dim">{words.toLocaleString()} words written</div>
    </div>
  );
}

function ToastHost() {
  const toast = useEbolt((s) => s.toast);
  const dismissToast = useEbolt((s) => s.dismissToast);
  if (!toast) return null;

  return (
    <div
      key={toast.id}
      role="status"
      aria-live="polite"
      className={cn(
        "toast-in fixed right-4 bottom-24 z-[90] flex items-center gap-3 rounded-xl border bg-navy/96 px-4 py-3 text-[12px] shadow-2xl backdrop-blur lg:bottom-6",
        toast.tone === "warn" ? "border-danger/40 text-danger" : "border-sky/25 text-ice",
      )}
    >
      <span>{toast.message}</span>
      {toast.action && toast.actionLabel && (
        <button
          className="rounded-lg border border-sky/30 px-2.5 py-1 text-[11px] font-semibold text-cream transition-colors hover:bg-sky/15"
          onClick={() => {
            toast.action?.();
          }}
        >
          {toast.actionLabel}
        </button>
      )}
      <button aria-label="Dismiss" className="text-dim transition-colors hover:text-cream" onClick={dismissToast}>
        <X className="size-3.5" />
      </button>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Home                                                                */
/* ------------------------------------------------------------------ */

function HomeView({ name }: { name: string }) {
  const go = useEbolt((s) => s.go);
  const newNote = useEbolt((s) => s.newNote);
  const saveNote = useEbolt((s) => s.saveNote);
  const loadNote = useEbolt((s) => s.loadNote);
  const draftTitle = useEbolt((s) => s.draftTitle);
  const draftText = useEbolt((s) => s.draftText);
  const setDraftTitle = useEbolt((s) => s.setDraftTitle);
  const setDraftText = useEbolt((s) => s.setDraftText);
  const currentNoteId = useEbolt((s) => s.currentNoteId);
  const notes = useEbolt((s) => s.notes);
  const dirty = useEbolt(selectDirty);

  const openNote = currentNoteId ? notes.find((n) => n.id === currentNoteId) : undefined;
  const recent = useMemo(() => sortNotes(notes, "updated").slice(0, 3), [notes]);

  // Rendered after mount only — the date string depends on the viewer's locale
  // and timezone, which the server cannot know.
  const [today, setToday] = useState<{ day: string; date: string } | null>(null);
  useEffect(() => {
    const now = new Date();
    setToday({
      day: now.toLocaleDateString(undefined, { weekday: "long" }),
      date: now.toLocaleDateString(undefined, { day: "numeric", month: "long", year: "numeric" }),
    });
  }, []);

  return (
    <section>
      <div className="mb-5 flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
        <div>
          <h2 className="font-display text-[27px] leading-tight tracking-tight">Hey, {name}</h2>
          <p className="mt-1 text-[12px] text-dim">Pick up where you left off.</p>
        </div>
        <div className="flex min-w-[210px] items-center gap-3 rounded-2xl border border-sky/12 bg-navy/70 px-3.5 py-2.5">
          <Orb size={40} />
          <div className="text-right">
            <strong className="block text-[12px] font-semibold">{today?.day ?? "\u00a0"}</strong>
            <span className="mt-0.5 block text-[10px] text-dim">{today?.date ?? "\u00a0"}</span>
          </div>
        </div>
      </div>

      <div className="relative isolate flex min-h-[420px] items-center justify-center overflow-hidden rounded-[30px] border border-sky/15 bg-[#04121a] text-center">
        <AuroraBackdrop />
        <div className="relative z-10 max-w-[760px] px-6 py-16">
          <h1 className="font-display text-[clamp(34px,6vw,70px)] leading-[1.04] font-semibold tracking-tight text-balance">
            <span className="aurora-text">Explore your ideas clearly.</span>
          </h1>
          <p className="mx-auto mt-6 max-w-[54ch] text-[13.5px] leading-7 text-muted">
            A quiet place to write, save and reshape what you are working on — every note kept on this
            device, ready the moment you come back.
          </p>
          <div className="mt-8 flex flex-wrap justify-center gap-2.5">
            <button className="pill pill-primary pill-lg" onClick={newNote}>
              Start a new note
            </button>
            <button className="pill pill-lg" onClick={() => go("saved")}>
              Browse {notes.length} {notes.length === 1 ? "note" : "notes"}
            </button>
          </div>
        </div>
      </div>

      <div className="mt-8 grid gap-4 lg:grid-cols-[minmax(0,1fr)_320px]">
        <div className="overflow-hidden rounded-[20px] border border-sky/18 bg-[#02080c]">
          <div className="flex h-12 flex-wrap items-center gap-2 border-b border-sky/10 px-3">
            <FileText className="size-3.5 shrink-0 text-sky" />
            <input
              className="h-8 min-w-0 flex-1 rounded-md border border-sky/18 bg-white/5 px-2.5 text-[12px] text-ice outline-none focus:border-sky/50"
              value={draftTitle}
              onChange={(e) => setDraftTitle(e.target.value)}
              aria-label="Note title"
            />
            {openNote && (
              <button className="pill" onClick={() => saveNote({ asNew: true })} title="Keep the original and save a copy">
                Save as new
              </button>
            )}
            <button className="pill pill-primary" onClick={() => saveNote()}>
              {openNote ? "Update" : "Save"}
            </button>
          </div>

          {/* The quick pad and the editor share one draft, so say plainly which
              note a save will overwrite. */}
          <div className="flex items-center justify-between gap-2 border-b border-sky/8 px-3.5 py-2 text-[11px] text-dim">
            <span className="truncate">
              {openNote ? (
                <>
                  Editing <b className="font-medium text-muted">{openNote.title}</b>
                </>
              ) : (
                "New note — not saved yet"
              )}
            </span>
            <span className={cn("shrink-0", dirty ? "text-sky" : "text-dim")}>
              {dirty ? "Unsaved changes" : "All changes saved"}
            </span>
          </div>

          <textarea
            className="min-h-[280px] w-full resize-y border-0 bg-transparent p-4 font-mono text-[12.5px] leading-7 text-ice outline-none placeholder:text-dim"
            value={draftText}
            placeholder="Start writing here. Ideas, commands, documentation — whatever you need to keep."
            onChange={(e) => setDraftText(e.target.value)}
            aria-label="Note text"
          />
        </div>

        <aside className="glass-card rounded-[20px] p-4">
          <div className="mb-3 flex items-center justify-between">
            <h3 className="text-[13px] font-semibold">Recent</h3>
            <button className="text-[11px] text-sky transition-colors hover:text-ice" onClick={() => go("saved")}>
              See all
            </button>
          </div>
          {recent.length === 0 ? (
            <p className="py-6 text-[12px] leading-6 text-dim">
              Nothing saved yet. Write something in the pad and press Save — it will appear here.
            </p>
          ) : (
            <ul className="grid gap-1.5">
              {recent.map((n) => (
                <li key={n.id}>
                  <button
                    className="w-full rounded-xl border border-sky/10 bg-white/3 px-3 py-2.5 text-left transition-colors hover:border-sky/30 hover:bg-sky/5"
                    onClick={() => loadNote(n.id)}
                  >
                    <b className="block truncate text-[12px] font-medium text-cream">{n.title}</b>
                    <span className="mt-0.5 block truncate text-[10.5px] text-dim">
                      <ClientTime ts={n.updatedAt} /> · {wordCount(n.text)} words
                    </span>
                  </button>
                </li>
              ))}
            </ul>
          )}
        </aside>
      </div>
    </section>
  );
}

/** Relative timestamps are client-only to keep SSR output deterministic. */
function ClientTime({ ts }: { ts: number }) {
  const [label, setLabel] = useState("");
  useEffect(() => {
    setLabel(formatWhen(ts));
    const id = setInterval(() => setLabel(formatWhen(ts)), 60000);
    return () => clearInterval(id);
  }, [ts]);
  return <>{label || "\u00a0"}</>;
}

/* ------------------------------------------------------------------ */
/* Saved notes                                                         */
/* ------------------------------------------------------------------ */

function SavedView() {
  const notes = useEbolt((s) => s.notes);
  const query = useEbolt((s) => s.query);
  const sort = useEbolt((s) => s.sort);
  const setQuery = useEbolt((s) => s.setQuery);
  const setSort = useEbolt((s) => s.setSort);
  const loadNote = useEbolt((s) => s.loadNote);
  const deleteNote = useEbolt((s) => s.deleteNote);
  const duplicateNote = useEbolt((s) => s.duplicateNote);
  const newNote = useEbolt((s) => s.newNote);
  const [pendingDelete, setPendingDelete] = useState<Note | null>(null);

  const visible = useMemo(() => {
    const q = query.trim().toLowerCase();
    const filtered = q
      ? notes.filter((n) => n.title.toLowerCase().includes(q) || n.text.toLowerCase().includes(q))
      : notes;
    return sortNotes(filtered, sort);
  }, [notes, query, sort]);

  return (
    <section>
      <div className="mb-5 flex flex-col justify-between gap-3 sm:flex-row sm:items-end">
        <div>
          <h2 className="font-display text-[24px] tracking-tight">Your notes</h2>
          <p className="mt-1 text-[12px] text-dim">
            {notes.length} saved · open any note to keep editing it.
          </p>
        </div>
        <button className="pill pill-primary self-start sm:self-auto" onClick={newNote}>
          New note
        </button>
      </div>

      <div className="mb-5 flex flex-col gap-2 sm:flex-row sm:items-center">
        <div className="relative flex-1">
          <Search className="pointer-events-none absolute top-1/2 left-3.5 size-4 -translate-y-1/2 text-dim" />
          <input
            className="h-11 w-full rounded-xl border border-sky/15 bg-white/4 pr-3 pl-10 text-[13px] text-cream outline-none placeholder:text-dim focus:border-sky/45"
            placeholder="Search titles and text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            aria-label="Search notes"
          />
        </div>
        <label className="flex h-11 items-center gap-2 rounded-xl border border-sky/15 bg-white/4 px-3 text-[12px] text-dim">
          Sort
          <select
            className="bg-transparent text-[12px] text-cream outline-none"
            value={sort}
            onChange={(e) => setSort(e.target.value as SortKey)}
          >
            <option className="bg-navy" value="updated">
              Last edited
            </option>
            <option className="bg-navy" value="created">
              Date created
            </option>
            <option className="bg-navy" value="title">
              Title A–Z
            </option>
          </select>
        </label>
      </div>

      {notes.length === 0 ? (
        <EmptyState
          title="No notes here yet"
          body="Everything you save shows up on this page. Start with one and build from there."
          actionLabel="Write your first note"
          onAction={newNote}
        />
      ) : visible.length === 0 ? (
        <EmptyState
          title={`Nothing matches “${query.trim()}”`}
          body="Try a shorter search term, or clear the search to see every note."
          actionLabel="Clear search"
          onAction={() => setQuery("")}
        />
      ) : (
        <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
          {visible.map((n) => (
            <article
              key={n.id}
              className="glass-card relative flex min-h-[176px] flex-col rounded-[18px] p-4 transition-[transform,border-color] hover:-translate-y-0.5 hover:border-sky/35"
            >
              <button className="text-left" onClick={() => loadNote(n.id)} aria-label={`Open ${n.title}`}>
                <h3 className="mb-2 pr-16 text-[14px] leading-snug font-medium">{n.title}</h3>
                <p className="line-clamp-4 text-[11.5px] leading-6 text-dim">
                  {n.text.trim() || "This note is empty."}
                </p>
              </button>

              <div className="absolute top-3 right-3 flex gap-1">
                <button
                  type="button"
                  className="grid size-8 place-items-center rounded-[9px] border border-sky/15 bg-white/4 text-muted transition-colors hover:border-sky/40 hover:text-cream"
                  aria-label={`Duplicate ${n.title}`}
                  title="Duplicate"
                  onClick={() => duplicateNote(n.id)}
                >
                  <Copy className="size-3.5" />
                </button>
                <button
                  type="button"
                  className="grid size-8 place-items-center rounded-[9px] border border-sky/15 bg-white/4 text-muted transition-colors hover:border-danger/50 hover:bg-danger/10 hover:text-danger"
                  aria-label={`Delete ${n.title}`}
                  title="Delete"
                  onClick={() => setPendingDelete(n)}
                >
                  <Trash2 className="size-3.5" />
                </button>
              </div>

              <div className="mt-auto flex items-center justify-between pt-4">
                <small className="text-[10px] text-dim">
                  <ClientTime ts={n.updatedAt} /> · {wordCount(n.text)} words
                </small>
                <button type="button" className="pill inline-flex h-8 items-center gap-1.5" onClick={() => loadNote(n.id)}>
                  <Pencil className="size-3" /> Edit
                </button>
              </div>
            </article>
          ))}
        </div>
      )}

      <ConfirmDialog
        open={Boolean(pendingDelete)}
        title={`Delete “${pendingDelete?.title ?? ""}”?`}
        description="You can undo this from the message that appears, until it disappears."
        confirmLabel="Delete note"
        destructive
        onConfirm={() => {
          if (pendingDelete) deleteNote(pendingDelete.id);
        }}
        onClose={() => setPendingDelete(null)}
      />
    </section>
  );
}

function EmptyState({
  title,
  body,
  actionLabel,
  onAction,
}: {
  title: string;
  body: string;
  actionLabel: string;
  onAction: () => void;
}) {
  return (
    <div className="glass-card grid place-items-center rounded-[22px] px-6 py-16 text-center">
      <NotebookText className="mb-4 size-8 text-sky/60" />
      <h3 className="text-[16px] font-medium">{title}</h3>
      <p className="mx-auto mt-2 max-w-[42ch] text-[12px] leading-6 text-dim">{body}</p>
      <button className="pill pill-primary mt-5" onClick={onAction}>
        {actionLabel}
      </button>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Editor                                                              */
/* ------------------------------------------------------------------ */

function EditorView() {
  const currentNoteId = useEbolt((s) => s.currentNoteId);
  const notes = useEbolt((s) => s.notes);
  const draftTitle = useEbolt((s) => s.draftTitle);
  const draftText = useEbolt((s) => s.draftText);
  const setDraftTitle = useEbolt((s) => s.setDraftTitle);
  const setDraftText = useEbolt((s) => s.setDraftText);
  const saveNote = useEbolt((s) => s.saveNote);
  const newDraft = useEbolt((s) => s.newDraft);
  const deleteNote = useEbolt((s) => s.deleteNote);
  const go = useEbolt((s) => s.go);
  const dirty = useEbolt(selectDirty);

  const [renaming, setRenaming] = useState(false);
  const [confirmClear, setConfirmClear] = useState(false);
  const [pendingDelete, setPendingDelete] = useState(false);

  const openNote = currentNoteId ? notes.find((n) => n.id === currentNoteId) : undefined;
  const editing = Boolean(openNote);

  // Warn before a reload or tab close would throw away unsaved text.
  useEffect(() => {
    if (!dirty) return;
    function onBeforeUnload(e: BeforeUnloadEvent) {
      e.preventDefault();
      e.returnValue = "";
    }
    window.addEventListener("beforeunload", onBeforeUnload);
    return () => window.removeEventListener("beforeunload", onBeforeUnload);
  }, [dirty]);

  function clearEditor() {
    if (dirty) setConfirmClear(true);
    else newDraft();
  }

  return (
    <section>
      <div className="mb-5 flex flex-col justify-between gap-3 sm:flex-row sm:items-end">
        <div>
          <h2 className="font-display text-[24px] tracking-tight">{editing ? "Edit note" : "New note"}</h2>
          <p className="mt-1 text-[12px] text-dim">
            {editing
              ? "Saving writes back to this note. Use Save as new to keep both versions."
              : "Saving creates a new note. Press Ctrl+S or Cmd+S any time."}
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <button className="pill" onClick={clearEditor}>
            New
          </button>
          <button className="pill" onClick={() => go("saved")}>
            All notes
          </button>
          {editing && (
            <button className="pill" onClick={() => saveNote({ asNew: true })}>
              Save as new
            </button>
          )}
          <button className="pill pill-primary" onClick={() => saveNote()}>
            {editing ? "Update note" : "Save note"}
          </button>
        </div>
      </div>

      <div className="grid gap-4 lg:grid-cols-[minmax(0,1fr)_280px]">
        <div className="glass-card rounded-[20px] p-4">
          <input
            className="mb-3 h-12 w-full rounded-xl border border-sky/18 bg-white/5 px-3.5 text-[14px] font-medium text-cream outline-none focus:border-sky/50"
            value={draftTitle}
            onChange={(e) => setDraftTitle(e.target.value)}
            placeholder="Note title"
            aria-label="Note title"
          />
          <textarea
            className="min-h-[400px] w-full resize-y rounded-xl border border-sky/10 bg-black/20 p-3.5 font-mono text-[12.5px] leading-7 text-ice outline-none placeholder:text-dim focus:border-sky/35"
            value={draftText}
            onChange={(e) => setDraftText(e.target.value)}
            placeholder="Write here…"
            aria-label="Note text"
          />
          <div className="mt-3 flex flex-wrap items-center justify-between gap-2">
            <span className="text-[11px] text-dim">
              {wordCount(draftText)} words · {draftText.length} characters ·{" "}
              <span className={dirty ? "text-sky" : undefined}>
                {dirty ? "Unsaved changes" : "All changes saved"}
              </span>
            </span>
            <div className="flex gap-2">
              <button className="pill" onClick={() => setRenaming(true)}>
                Rename
              </button>
              {editing && (
                <button className="pill pill-danger" onClick={() => setPendingDelete(true)}>
                  Delete
                </button>
              )}
              <button className="pill pill-primary" onClick={() => saveNote()}>
                {editing ? "Update" : "Save"}
              </button>
            </div>
          </div>
        </div>

        <aside className="glass-card rounded-[20px] p-4">
          <h3 className="mb-3 text-[13px] font-semibold">How saving works</h3>
          <dl className="grid gap-3">
            {[
              ["Save", "Creates a new note the first time, then updates that same note."],
              ["Save as new", "Keeps the original untouched and stores a second copy."],
              ["Delete", "Removes the note, with a few seconds to undo."],
              ["Storage", "Notes live in this browser, separately for each account."],
            ].map(([term, detail]) => (
              <div key={term} className="border-b border-sky/8 pb-3 last:border-0 last:pb-0">
                <dt className="text-[11.5px] font-medium text-sky">{term}</dt>
                <dd className="mt-1 text-[11px] leading-5 text-dim">{detail}</dd>
              </div>
            ))}
          </dl>
        </aside>
      </div>

      <PromptDialog
        open={renaming}
        title="Rename note"
        description="This changes the title only. Save to write it to the note."
        initialValue={draftTitle}
        placeholder="Note title"
        submitLabel="Rename"
        onSubmit={(value) => setDraftTitle(value)}
        onClose={() => setRenaming(false)}
      />

      <ConfirmDialog
        open={confirmClear}
        title="Discard unsaved changes?"
        description="The editor will be cleared and your unsaved text will be lost."
        confirmLabel="Discard"
        destructive
        onConfirm={newDraft}
        onClose={() => setConfirmClear(false)}
      />

      <ConfirmDialog
        open={pendingDelete}
        title={`Delete “${openNote?.title ?? ""}”?`}
        description="You can undo this from the message that appears, until it disappears."
        confirmLabel="Delete note"
        destructive
        onConfirm={() => {
          if (currentNoteId) {
            deleteNote(currentNoteId);
            go("saved");
          }
        }}
        onClose={() => setPendingDelete(false)}
      />
    </section>
  );
}

/* ------------------------------------------------------------------ */
/* Assistant                                                           */
/* ------------------------------------------------------------------ */

function ChatView() {
  const chat = useEbolt((s) => s.chat);
  const sendChat = useEbolt((s) => s.sendChat);
  const [value, setValue] = useState("");
  const box = useRef<HTMLDivElement>(null);

  useEffect(() => {
    box.current?.scrollTo({ top: box.current.scrollHeight, behavior: "smooth" });
  }, [chat.length]);

  function onSubmit(e: FormEvent) {
    e.preventDefault();
    sendChat(value);
    setValue("");
  }

  return (
    <section>
      <div className="mb-5">
        <h2 className="font-display text-[24px] tracking-tight">Assistant</h2>
        <p className="mt-1 text-[12px] text-dim">Ask about your notes, or talk an idea through.</p>
      </div>
      <div className="glass-card flex min-h-[600px] flex-col overflow-hidden rounded-[22px]">
        <div className="flex items-center gap-3 border-b border-sky/10 px-4 py-4">
          <img src="/ebolt-logo.png" alt="" className="size-10 rounded-xl object-cover" />
          <div>
            <b className="text-[13px] font-semibold">Ebolt assistant</b>
            <span className="mt-0.5 block text-[10.5px] text-dim">Knows what is in your workspace</span>
          </div>
        </div>
        <div ref={box} className="flex flex-1 flex-col gap-3 overflow-auto p-5">
          {chat.map((m, i) => (
            <div
              key={i}
              className={cn(
                "max-w-[75%] rounded-[16px] px-4 py-3 text-[12px] leading-6",
                m.role === "bot"
                  ? "self-start border border-sky/10 bg-sky/8 text-ice"
                  : "self-end bg-linear-to-r from-sky-2 to-ice text-navy",
              )}
            >
              {m.text}
            </div>
          ))}
        </div>
        <form className="flex gap-2 border-t border-sky/10 p-3" onSubmit={onSubmit}>
          <input
            className="h-11 flex-1 rounded-xl border border-sky/18 bg-white/5 px-3.5 text-[13px] text-cream outline-none placeholder:text-dim focus:border-sky/50"
            placeholder="Ask something about your notes…"
            value={value}
            onChange={(e) => setValue(e.target.value)}
            aria-label="Message"
          />
          <button className="pill pill-primary h-11" type="submit" disabled={!value.trim()}>
            Send
          </button>
        </form>
      </div>
    </section>
  );
}
