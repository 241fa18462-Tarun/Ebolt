import { FormEvent, ReactNode, useEffect, useId, useRef, useState } from "react";
import { cn } from "@/lib/cn";

type BaseProps = {
  open: boolean;
  title: string;
  description?: ReactNode;
  onClose: () => void;
};

function useDialogBehaviour(open: boolean, onClose: () => void) {
  const ref = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (!open) return;
    const previous = document.activeElement as HTMLElement | null;
    const node = ref.current;
    node?.querySelector<HTMLElement>("[data-autofocus]")?.focus();

    function onKeyDown(e: KeyboardEvent) {
      if (e.key === "Escape") {
        e.preventDefault();
        onClose();
        return;
      }
      if (e.key !== "Tab" || !node) return;
      const focusables = node.querySelectorAll<HTMLElement>(
        'button, input, textarea, [href], [tabindex]:not([tabindex="-1"])',
      );
      if (!focusables.length) return;
      const first = focusables[0];
      const last = focusables[focusables.length - 1];
      if (e.shiftKey && document.activeElement === first) {
        e.preventDefault();
        last.focus();
      } else if (!e.shiftKey && document.activeElement === last) {
        e.preventDefault();
        first.focus();
      }
    }

    document.addEventListener("keydown", onKeyDown);
    const overflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKeyDown);
      document.body.style.overflow = overflow;
      previous?.focus?.();
    };
  }, [open, onClose]);

  return ref;
}

function Shell({
  open,
  title,
  description,
  onClose,
  children,
}: BaseProps & { children: ReactNode }) {
  const ref = useDialogBehaviour(open, onClose);
  const titleId = useId();
  if (!open) return null;

  return (
    <div className="fixed inset-0 z-[100] grid place-items-center p-4">
      <div className="dialog-scrim absolute inset-0" onClick={onClose} />
      <div
        ref={ref}
        role="dialog"
        aria-modal="true"
        aria-labelledby={titleId}
        className="dialog-panel relative w-full max-w-[420px] rounded-[22px] p-6"
      >
        <h2 id={titleId} className="text-[16px] font-semibold tracking-tight text-cream">
          {title}
        </h2>
        {description && <div className="mt-2 text-[12px] leading-6 text-muted">{description}</div>}
        {children}
      </div>
    </div>
  );
}

export function ConfirmDialog({
  open,
  title,
  description,
  confirmLabel = "Confirm",
  cancelLabel = "Cancel",
  destructive = false,
  onConfirm,
  onClose,
}: BaseProps & {
  confirmLabel?: string;
  cancelLabel?: string;
  destructive?: boolean;
  onConfirm: () => void;
}) {
  return (
    <Shell open={open} title={title} description={description} onClose={onClose}>
      <div className="mt-6 flex justify-end gap-2">
        <button type="button" className="pill" onClick={onClose}>
          {cancelLabel}
        </button>
        <button
          type="button"
          data-autofocus
          className={cn("pill", destructive ? "pill-danger" : "pill-primary")}
          onClick={() => {
            onConfirm();
            onClose();
          }}
        >
          {confirmLabel}
        </button>
      </div>
    </Shell>
  );
}

export function PromptDialog({
  open,
  title,
  description,
  initialValue = "",
  placeholder,
  submitLabel = "Save",
  onSubmit,
  onClose,
}: BaseProps & {
  initialValue?: string;
  placeholder?: string;
  submitLabel?: string;
  onSubmit: (value: string) => void;
}) {
  const [value, setValue] = useState(initialValue);

  useEffect(() => {
    if (open) setValue(initialValue);
  }, [open, initialValue]);

  function handleSubmit(e: FormEvent) {
    e.preventDefault();
    const trimmed = value.trim();
    if (!trimmed) return;
    onSubmit(trimmed);
    onClose();
  }

  return (
    <Shell open={open} title={title} description={description} onClose={onClose}>
      <form onSubmit={handleSubmit}>
        <input
          data-autofocus
          className="mt-5 h-11 w-full rounded-xl border border-sky/25 bg-white/5 px-3.5 text-[13px] text-cream outline-none focus:border-sky/60"
          value={value}
          placeholder={placeholder}
          onChange={(e) => setValue(e.target.value)}
        />
        <div className="mt-5 flex justify-end gap-2">
          <button type="button" className="pill" onClick={onClose}>
            Cancel
          </button>
          <button type="submit" className="pill pill-primary" disabled={!value.trim()}>
            {submitLabel}
          </button>
        </div>
      </form>
    </Shell>
  );
}
