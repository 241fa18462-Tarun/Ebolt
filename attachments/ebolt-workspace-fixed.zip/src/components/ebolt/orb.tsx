import { cn } from "@/lib/cn";

type Props = {
  size?: number;
  className?: string;
};

export function Orb({ size = 42, className }: Props) {
  return (
    <span
      className={cn("relative inline-grid shrink-0 place-items-center overflow-hidden rounded-full orb-ring", className)}
      style={{ width: size, height: size }}
      aria-hidden="true"
    >
      <video
        className="h-full w-full scale-110 object-cover"
        src="/orb.mp4"
        autoPlay
        loop
        muted
        playsInline
        preload="auto"
      />
    </span>
  );
}
