import { useEffect, useRef } from "react";
import { cn } from "@/lib/cn";

type Particle = {
  x: number;
  y: number;
  r: number;
  vx: number;
  vy: number;
  hue: number;
  phase: number;
};

type Streak = {
  x: number;
  y: number;
  len: number;
  speed: number;
  life: number;
  maxLife: number;
  angle: number;
};

const HUES = [193, 178, 205, 262];

/**
 * Continuously animating backdrop: drifting light motes that link into a
 * constellation mesh, with occasional streaks crossing the field. Drawn on a
 * single canvas so the cost stays flat no matter how many motes are on screen.
 *
 * Pauses entirely when the tab is hidden and draws one static frame when the
 * viewer prefers reduced motion.
 */
export function AuroraCanvas({ className }: { className?: string }) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const reduced =
      typeof window.matchMedia === "function" &&
      window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    let width = 0;
    let height = 0;
    let dpr = 1;
    let particles: Particle[] = [];
    let streaks: Streak[] = [];
    let frame = 0;
    let running = true;
    let last = 0;

    function seed() {
      const area = width * height;
      // Roughly one mote per 14k css pixels, clamped so phones stay light.
      const count = Math.max(16, Math.min(94, Math.round(area / 11000)));
      particles = Array.from({ length: count }, () => ({
        x: Math.random() * width,
        y: Math.random() * height,
        r: Math.random() * 1.7 + 0.6,
        vx: (Math.random() - 0.5) * 0.14,
        vy: -(Math.random() * 0.17 + 0.04),
        hue: HUES[Math.floor(Math.random() * HUES.length)],
        phase: Math.random() * Math.PI * 2,
      }));
      streaks = [];
    }

    function resize() {
      const rect = canvas!.getBoundingClientRect();
      if (!rect.width || !rect.height) return;
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      width = rect.width;
      height = rect.height;
      canvas!.width = Math.round(width * dpr);
      canvas!.height = Math.round(height * dpr);
      ctx!.setTransform(dpr, 0, 0, dpr, 0, 0);
      seed();
    }

    function spawnStreak() {
      const fromLeft = Math.random() > 0.5;
      streaks.push({
        x: fromLeft ? -60 : width + 60,
        y: Math.random() * height * 0.7,
        len: 90 + Math.random() * 130,
        speed: (fromLeft ? 1 : -1) * (2.6 + Math.random() * 2.2),
        life: 0,
        maxLife: 90 + Math.random() * 50,
        angle: (fromLeft ? 1 : -1) * (0.12 + Math.random() * 0.1),
      });
    }

    function draw(now: number) {
      if (!running) return;
      const dt = last ? Math.min((now - last) / 16.667, 2.5) : 1;
      last = now;
      frame += dt;

      ctx!.clearRect(0, 0, width, height);

      // Constellation mesh — drawn before the motes so lines sit underneath.
      ctx!.lineWidth = 1;
      for (let i = 0; i < particles.length; i++) {
        for (let j = i + 1; j < particles.length; j++) {
          const a = particles[i];
          const b = particles[j];
          const dx = a.x - b.x;
          const dy = a.y - b.y;
          const dist2 = dx * dx + dy * dy;
          if (dist2 > 13000) continue;
          const alpha = (1 - dist2 / 13000) * 0.3;
          ctx!.strokeStyle = `hsla(193, 82%, 76%, ${alpha})`;
          ctx!.beginPath();
          ctx!.moveTo(a.x, a.y);
          ctx!.lineTo(b.x, b.y);
          ctx!.stroke();
        }
      }

      for (const p of particles) {
        if (!reduced) {
          p.x += p.vx * dt + Math.sin((frame + p.phase * 40) / 90) * 0.12 * dt;
          p.y += p.vy * dt;
          if (p.y < -12) {
            p.y = height + 12;
            p.x = Math.random() * width;
          }
          if (p.x < -12) p.x = width + 12;
          if (p.x > width + 12) p.x = -12;
        }

        const twinkle = reduced ? 0.6 : 0.45 + Math.sin(frame / 40 + p.phase) * 0.3;
        const glow = ctx!.createRadialGradient(p.x, p.y, 0, p.x, p.y, p.r * 7);
        glow.addColorStop(0, `hsla(${p.hue}, 92%, 82%, ${0.55 * twinkle})`);
        glow.addColorStop(1, `hsla(${p.hue}, 92%, 72%, 0)`);
        ctx!.fillStyle = glow;
        ctx!.beginPath();
        ctx!.arc(p.x, p.y, p.r * 7, 0, Math.PI * 2);
        ctx!.fill();

        ctx!.fillStyle = `hsla(${p.hue}, 100%, 92%, ${0.85 * twinkle})`;
        ctx!.beginPath();
        ctx!.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx!.fill();
      }

      if (!reduced) {
        if (streaks.length < 2 && Math.random() < 0.006 * dt) spawnStreak();

        for (const s of streaks) {
          s.life += dt;
          s.x += s.speed * dt;
          s.y += s.angle * Math.abs(s.speed) * dt;
          const fade = 1 - s.life / s.maxLife;
          if (fade <= 0) continue;
          const tailX = s.x - Math.sign(s.speed) * s.len;
          const tailY = s.y - s.angle * s.len;
          const grad = ctx!.createLinearGradient(tailX, tailY, s.x, s.y);
          grad.addColorStop(0, "hsla(193, 90%, 80%, 0)");
          grad.addColorStop(1, `hsla(188, 100%, 88%, ${0.5 * fade})`);
          ctx!.strokeStyle = grad;
          ctx!.lineWidth = 1.6;
          ctx!.beginPath();
          ctx!.moveTo(tailX, tailY);
          ctx!.lineTo(s.x, s.y);
          ctx!.stroke();
        }
        streaks = streaks.filter((s) => s.life < s.maxLife && s.x > -400 && s.x < width + 400);

        raf = requestAnimationFrame(draw);
      }
    }

    let raf = 0;
    resize();
    raf = requestAnimationFrame(draw);

    const observer =
      typeof ResizeObserver !== "undefined"
        ? new ResizeObserver(() => {
            resize();
            if (reduced) {
              cancelAnimationFrame(raf);
              raf = requestAnimationFrame(draw);
            }
          })
        : null;
    observer?.observe(canvas);
    window.addEventListener("resize", resize);

    // Stop burning frames while the tab is in the background.
    function onVisibility() {
      if (document.hidden) {
        running = false;
        cancelAnimationFrame(raf);
      } else if (!running) {
        running = true;
        last = 0;
        raf = requestAnimationFrame(draw);
      }
    }
    document.addEventListener("visibilitychange", onVisibility);

    return () => {
      running = false;
      cancelAnimationFrame(raf);
      observer?.disconnect();
      window.removeEventListener("resize", resize);
      document.removeEventListener("visibilitychange", onVisibility);
    };
  }, []);

  return <canvas ref={canvasRef} className={cn("pointer-events-none absolute inset-0 h-full w-full", className)} aria-hidden="true" />;
}

/**
 * The full hero backdrop: layered colour fields that drift against each other,
 * a slow-scrolling grid for depth, and the canvas mesh on top.
 */
export function AuroraBackdrop() {
  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden" aria-hidden="true">
      <div className="aurora-veil aurora-veil-a" />
      <div className="aurora-veil aurora-veil-b" />
      <div className="aurora-veil aurora-veil-c" />
      <div className="aurora-grid" />
      <AuroraCanvas className="aurora-mesh" />
      <div className="aurora-core" />
      <div className="aurora-sheen" />
      <div className="aurora-vignette" />
    </div>
  );
}
