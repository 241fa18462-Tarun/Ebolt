import { create } from "zustand";

export type EboltPage = "home" | "new" | "saved" | "chat";

export type Note = {
  id: string;
  title: string;
  text: string;
  createdAt: number;
  updatedAt: number;
};

export type Account = {
  email: string;
  password: string;
  fullName?: string;
};

export type Toast = {
  id: number;
  message: string;
  tone: "ok" | "warn";
  actionLabel?: string;
  action?: () => void;
};

type ChatMsg = { role: "user" | "bot"; text: string };

export type SortKey = "updated" | "created" | "title";

const NOTES_PREFIX = "ebolt_notes_v2::";
const LEGACY_NOTES_KEY = "ebolt_notes";
const REMEMBER_KEY = "ebolt_remember";
const ACCOUNTS_KEY = "ebolt_accounts";

const BLANK_TITLE = "Untitled note";
const BLANK_TEXT = "";

/* ------------------------------------------------------------------ */
/* storage helpers                                                     */
/* ------------------------------------------------------------------ */

function hasStorage() {
  try {
    return typeof window !== "undefined" && !!window.localStorage;
  } catch {
    return false;
  }
}

export function newId() {
  try {
    if (typeof crypto !== "undefined" && "randomUUID" in crypto) {
      return `note_${crypto.randomUUID()}`;
    }
  } catch {
    /* ignore */
  }
  return `note_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 10)}`;
}

function notesKey(email: string) {
  return `${NOTES_PREFIX}${email.trim().toLowerCase()}`;
}

/**
 * Coerce whatever is in storage into valid notes. Anything that is not an
 * object is dropped instead of throwing, ids are only invented when genuinely
 * missing, and duplicate ids are repaired so edit/delete can never hit the
 * wrong record.
 */
function coerceNotes(raw: unknown): { notes: Note[]; changed: boolean } {
  if (!Array.isArray(raw)) return { notes: [], changed: false };
  const seen = new Set<string>();
  let changed = false;
  const notes: Note[] = [];

  for (const entry of raw) {
    if (!entry || typeof entry !== "object") {
      changed = true;
      continue;
    }
    const n = entry as Record<string, unknown>;

    let id = typeof n.id === "string" && n.id.trim() ? n.id : "";
    if (!id || seen.has(id)) {
      id = newId();
      changed = true;
    }
    seen.add(id);

    // v1 stored `updated` as a locale string, which cannot be sorted and
    // differs between server and client. Migrate it to epoch milliseconds.
    let updatedAt = typeof n.updatedAt === "number" ? n.updatedAt : NaN;
    if (!Number.isFinite(updatedAt)) {
      const parsed = typeof n.updated === "string" ? Date.parse(n.updated) : NaN;
      updatedAt = Number.isFinite(parsed) ? parsed : Date.now();
      changed = true;
    }
    let createdAt = typeof n.createdAt === "number" ? n.createdAt : NaN;
    if (!Number.isFinite(createdAt)) {
      createdAt = updatedAt;
      changed = true;
    }

    notes.push({
      id,
      title: typeof n.title === "string" && n.title.trim() ? n.title : BLANK_TITLE,
      text: typeof n.text === "string" ? n.text : "",
      createdAt,
      updatedAt,
    });
  }

  return { notes, changed };
}

function loadNotes(email: string): Note[] {
  if (!hasStorage()) return [];
  const key = notesKey(email);
  let stored: string | null = null;
  try {
    stored = localStorage.getItem(key);
  } catch {
    return [];
  }

  // One-time migration: v1 kept every account's notes in a single global
  // bucket, so signing in as a second person exposed the first person's notes.
  if (stored === null) {
    try {
      const legacy = localStorage.getItem(LEGACY_NOTES_KEY);
      if (legacy !== null) {
        const migrated = coerceNotes(safeParse(legacy)).notes;
        saveNotes(email, migrated);
        localStorage.removeItem(LEGACY_NOTES_KEY);
        return sortNotes(migrated, "updated");
      }
    } catch {
      /* ignore */
    }
    return [];
  }

  const { notes, changed } = coerceNotes(safeParse(stored));
  if (changed) saveNotes(email, notes);
  return sortNotes(notes, "updated");
}

function safeParse(raw: string): unknown {
  try {
    return JSON.parse(raw);
  } catch {
    return null;
  }
}

/** Returns false when the write failed (private mode, quota exceeded, ...). */
function saveNotes(email: string, notes: Note[]): boolean {
  if (!hasStorage()) return false;
  try {
    localStorage.setItem(notesKey(email), JSON.stringify(notes));
    return true;
  } catch {
    return false;
  }
}

export function sortNotes(notes: Note[], key: SortKey): Note[] {
  const copy = [...notes];
  if (key === "title") {
    copy.sort((a, b) => a.title.localeCompare(b.title) || b.updatedAt - a.updatedAt);
  } else if (key === "created") {
    copy.sort((a, b) => b.createdAt - a.createdAt);
  } else {
    copy.sort((a, b) => b.updatedAt - a.updatedAt);
  }
  return copy;
}

export function readAccounts(): Record<string, Account> {
  if (!hasStorage()) return {};
  try {
    const parsed = safeParse(localStorage.getItem(ACCOUNTS_KEY) || "{}");
    if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) return {};
    return parsed as Record<string, Account>;
  } catch {
    return {};
  }
}

export function writeAccounts(accounts: Record<string, Account>) {
  if (!hasStorage()) return;
  try {
    localStorage.setItem(ACCOUNTS_KEY, JSON.stringify(accounts));
  } catch {
    /* ignore */
  }
}

export function tryRememberedUser(): Account | null {
  if (!hasStorage()) return null;
  const parsed = safeParse(localStorage.getItem(REMEMBER_KEY) || "null");
  if (!parsed || typeof parsed !== "object") return null;
  const u = parsed as Partial<Account>;
  if (typeof u.email !== "string" || typeof u.password !== "string") return null;
  return { email: u.email, password: u.password, fullName: u.fullName };
}

export function rememberUser(user: Account) {
  if (!hasStorage()) return;
  try {
    localStorage.setItem(REMEMBER_KEY, JSON.stringify(user));
  } catch {
    /* ignore */
  }
}

export function displayName(email: string, fullName?: string) {
  if (fullName?.trim()) return fullName.trim();
  return email
    .split("@")[0]
    .replace(/[._-]+/g, " ")
    .replace(/\b\w/g, (c) => c.toUpperCase());
}

/** Formatted on the client only — never during SSR, so locales cannot mismatch. */
export function formatWhen(ts: number) {
  const diff = Date.now() - ts;
  const min = Math.round(diff / 60000);
  if (min < 1) return "Just now";
  if (min < 60) return `${min}m ago`;
  const hrs = Math.round(min / 60);
  if (hrs < 24) return `${hrs}h ago`;
  const days = Math.round(hrs / 24);
  if (days < 7) return `${days}d ago`;
  return new Date(ts).toLocaleDateString(undefined, {
    day: "numeric",
    month: "short",
    year: "numeric",
  });
}

export function wordCount(text: string) {
  const t = text.trim();
  return t ? t.split(/\s+/).length : 0;
}

/* ------------------------------------------------------------------ */
/* store                                                               */
/* ------------------------------------------------------------------ */

export type State = {
  user: Account | null;
  hydrated: boolean;
  page: EboltPage;
  notes: Note[];
  currentNoteId: string | null;
  draftTitle: string;
  draftText: string;
  /** Title+text as of the last save/open — used to detect unsaved changes. */
  baseline: { title: string; text: string };
  query: string;
  sort: SortKey;
  toast: Toast | null;
  chat: ChatMsg[];

  login: (user: Account) => void;
  logout: () => void;
  hydrateNotes: () => void;
  go: (page: EboltPage) => void;
  setDraftTitle: (v: string) => void;
  setDraftText: (v: string) => void;
  newDraft: () => void;
  newNote: () => void;
  saveNote: (opts?: { asNew?: boolean }) => void;
  loadNote: (id: string) => void;
  duplicateNote: (id: string) => void;
  deleteNote: (id: string) => void;
  setQuery: (v: string) => void;
  setSort: (v: SortKey) => void;
  showToast: (message: string, opts?: Partial<Omit<Toast, "id" | "message">>) => void;
  dismissToast: () => void;
  sendChat: (text: string) => void;
};

let toastTimer: ReturnType<typeof setTimeout> | undefined;
let toastSeq = 0;

const GREETING: ChatMsg = {
  role: "bot",
  text: "Hi! I'm your Ebolt assistant. Tell me what you want to write, organize or improve.",
};

export const useEbolt = create<State>((set, get) => ({
  // Deterministic initial state: reading localStorage here would make the
  // server and the first client render disagree and break hydration.
  user: null,
  hydrated: false,
  page: "home",
  notes: [],
  currentNoteId: null,
  draftTitle: BLANK_TITLE,
  draftText: BLANK_TEXT,
  baseline: { title: BLANK_TITLE, text: BLANK_TEXT },
  query: "",
  sort: "updated",
  toast: null,
  chat: [GREETING],

  login: (user) => {
    set({
      user,
      page: "home",
      notes: [],
      hydrated: false,
      currentNoteId: null,
      draftTitle: BLANK_TITLE,
      draftText: BLANK_TEXT,
      baseline: { title: BLANK_TITLE, text: BLANK_TEXT },
      query: "",
      chat: [GREETING],
    });
    get().hydrateNotes();
  },

  logout: () => {
    if (hasStorage()) {
      try {
        localStorage.removeItem(REMEMBER_KEY);
      } catch {
        /* ignore */
      }
    }
    // Clear notes from memory too, so the next person on this device never
    // sees the previous account's notes flash on screen.
    set({
      user: null,
      hydrated: false,
      page: "home",
      notes: [],
      currentNoteId: null,
      draftTitle: BLANK_TITLE,
      draftText: BLANK_TEXT,
      baseline: { title: BLANK_TITLE, text: BLANK_TEXT },
      query: "",
      chat: [GREETING],
    });
  },

  hydrateNotes: () => {
    const user = get().user;
    if (!user || typeof window === "undefined") return;
    set({ notes: loadNotes(user.email), hydrated: true });
  },

  go: (page) => set({ page }),
  setDraftTitle: (draftTitle) => set({ draftTitle }),
  setDraftText: (draftText) => set({ draftText }),

  /** Reset the editor without navigating — used by Home's quick pad. */
  newDraft: () =>
    set({
      currentNoteId: null,
      draftTitle: BLANK_TITLE,
      draftText: BLANK_TEXT,
      baseline: { title: BLANK_TITLE, text: BLANK_TEXT },
    }),

  newNote: () => {
    get().newDraft();
    set({ page: "new" });
  },

  saveNote: ({ asNew = false } = {}) => {
    const { draftTitle, draftText, currentNoteId, notes, user } = get();
    if (!user) return;

    // An untouched draft has the placeholder title and no body — saving it
    // would just litter the list with blank "Untitled note" cards.
    const titled = draftTitle.trim() && draftTitle.trim() !== BLANK_TITLE;
    if (!titled && !draftText.trim()) {
      get().showToast("Write something first, then save", { tone: "warn" });
      return;
    }

    const title = draftTitle.trim() || BLANK_TITLE;
    const text = draftText;

    const now = Date.now();
    let next: Note[];
    let id = asNew ? null : currentNoteId;
    const existingIndex = id ? notes.findIndex((n) => n.id === id) : -1;

    if (id && existingIndex >= 0) {
      next = [...notes];
      next[existingIndex] = { ...next[existingIndex], title, text, updatedAt: now };
    } else {
      // Either a brand-new note, an explicit "save as new", or a stale id whose
      // note was deleted elsewhere — all of these create a fresh record.
      id = newId();
      next = [{ id, title, text, createdAt: now, updatedAt: now }, ...notes];
    }

    const ok = saveNotes(user.email, next);
    if (!ok) {
      get().showToast("Couldn't save — device storage is full or blocked", { tone: "warn" });
      return;
    }

    set({
      notes: sortNotes(next, get().sort),
      currentNoteId: id,
      draftTitle: title,
      // Never rewrite the body the user is typing into; only the baseline moves.
      baseline: { title, text },
    });
    get().showToast(existingIndex >= 0 ? "Note updated" : "Note saved");
  },

  loadNote: (id) => {
    const n = get().notes.find((x) => x.id === id);
    if (!n) {
      get().showToast("That note no longer exists", { tone: "warn" });
      return;
    }
    set({
      currentNoteId: n.id,
      draftTitle: n.title,
      draftText: n.text,
      baseline: { title: n.title, text: n.text },
      page: "new",
    });
  },

  duplicateNote: (id) => {
    const { notes, user } = get();
    const source = notes.find((n) => n.id === id);
    if (!source || !user) return;
    const now = Date.now();
    const copy: Note = {
      id: newId(),
      title: `${source.title} (copy)`,
      text: source.text,
      createdAt: now,
      updatedAt: now,
    };
    const next = [copy, ...notes];
    if (!saveNotes(user.email, next)) {
      get().showToast("Couldn't duplicate — storage is full or blocked", { tone: "warn" });
      return;
    }
    set({ notes: sortNotes(next, get().sort) });
    get().showToast("Note duplicated");
  },

  deleteNote: (id) => {
    const { notes, currentNoteId, user } = get();
    if (!user) return;
    const removed = notes.find((n) => n.id === id);
    if (!removed) return;

    const next = notes.filter((n) => n.id !== id);
    if (!saveNotes(user.email, next)) {
      get().showToast("Couldn't delete — storage is blocked", { tone: "warn" });
      return;
    }

    if (currentNoteId === id) {
      set({
        notes: next,
        currentNoteId: null,
        draftTitle: BLANK_TITLE,
        draftText: BLANK_TEXT,
        baseline: { title: BLANK_TITLE, text: BLANK_TEXT },
      });
    } else {
      set({ notes: next });
    }

    get().showToast(`Deleted "${removed.title}"`, {
      actionLabel: "Undo",
      action: () => {
        const state = get();
        if (!state.user) return;
        const restored = sortNotes([...state.notes, removed], state.sort);
        if (!saveNotes(state.user.email, restored)) return;
        set({ notes: restored });
        state.showToast("Note restored");
      },
    });
  },

  setQuery: (query) => set({ query }),
  setSort: (sort) => set({ sort, notes: sortNotes(get().notes, sort) }),

  showToast: (message, opts = {}) => {
    if (toastTimer) clearTimeout(toastTimer);
    const toast: Toast = {
      id: ++toastSeq,
      message,
      tone: opts.tone ?? "ok",
      actionLabel: opts.actionLabel,
      action: opts.action,
    };
    set({ toast });
    // Leave undoable toasts on screen long enough to actually be clicked.
    toastTimer = setTimeout(() => {
      if (get().toast?.id === toast.id) set({ toast: null });
    }, toast.action ? 6000 : 2400);
  },

  dismissToast: () => {
    if (toastTimer) clearTimeout(toastTimer);
    set({ toast: null });
  },

  sendChat: (text) => {
    const trimmed = text.trim();
    if (!trimmed) return;
    const notes = get().notes;
    const lower = trimmed.toLowerCase();
    let reply =
      "I can help you shape that idea. Try capturing the main goal, the next action and any key details in a note.";
    if (lower.includes("how many") || lower.includes("count")) {
      reply = `You have ${notes.length} saved ${notes.length === 1 ? "note" : "notes"} in this workspace.`;
    } else if (lower.includes("delete") || lower.includes("remove")) {
      reply = "Open Saved Notes, then use the delete button on a card. You get an Undo for a few seconds.";
    } else if (lower.includes("edit") || lower.includes("update")) {
      reply = "Click any saved note to open it in the editor. Save writes it back to the same note.";
    } else if (notes.length) {
      const match = notes.find(
        (n) => n.title.toLowerCase().includes(lower) || n.text.toLowerCase().includes(lower),
      );
      if (match) reply = `That looks related to your note "${match.title}". Open it from Saved Notes to continue.`;
    }
    set({ chat: [...get().chat, { role: "user", text: trimmed }, { role: "bot", text: reply }] });
  },
}));

/** True when the editor has changes that have not been written to storage. */
export function selectDirty(s: State) {
  return s.draftTitle !== s.baseline.title || s.draftText !== s.baseline.text;
}
