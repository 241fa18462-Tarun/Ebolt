import { useEffect } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { LoginScreen } from "@/components/ebolt/login-screen";
import { Workspace } from "@/components/ebolt/workspace";
import { tryRememberedUser, useEbolt } from "@/lib/ebolt-store";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const user = useEbolt((s) => s.user);
  const login = useEbolt((s) => s.login);

  useEffect(() => {
    if (user) return;
    const remembered = tryRememberedUser();
    if (remembered) login(remembered);
  }, [user, login]);

  if (!user) return <LoginScreen />;
  return <Workspace />;
}
