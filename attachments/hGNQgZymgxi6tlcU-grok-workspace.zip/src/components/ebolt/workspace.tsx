import { FormEvent, useEffect, useMemo, useRef, useState } from "react";
import {
  Home,
  Plus,
  NotebookText,
  Sparkles,
  Pencil,
  X,
  LogOut,
} from "lucide-react";
import { cn } from "@/lib/cn";
import { displayName, type EboltPage, useEbolt } from "@/lib/ebolt-store";
import { Orb } from "./orb";

const NAV: { id: EboltPage; label: string; icon: typeof Home }[] = [
  { id: "home", label: "Home", icon: Home },
  { id: "new", label: "New Note", icon: Plus },
  { id: "saved", label: "Saved Note", icon: NotebookText },
  { id: "chat", label: "AI Chat Bot", icon: Sparkles },
];

export function Workspace() {
  const user = useEbolt((s) => s.user)!;
  const page = useEbolt((s) => s.page);
  const go = useEbolt((s) => s.go);
  const logout = useEbolt((s) => s.logout);
  const toast = useEbolt((s) => s.toast);
  const name = displayName(user.email, user.fullName);
  const initial = name.charAt(0).toUpperCase();

  return (
    <div className="app-bg min-h-screen text-cream">
      <div className="grid min-h-screen lg:grid-cols-[205px_1fr]">
        <aside className="sticky top-0 z-20 hidden h-screen flex-col border-r border-sky/15 bg-ink/94 px-3 py-5 backdrop-blur-xl lg:flex">
          <div className="mb-5 flex items-center gap-3 px-2">
            <img src="/ebolt-logo.png" alt="" className="size-10 rounded-full border-2 border-white/70 object-cover" />
            <span className="text-[15px] font-extrabold tracking-[1.8px]">EBOLT</span>
          </div>
          <div className="mb-4 flex items-center gap-2.5 rounded-2xl border border-sky/15 bg-white/5 p-3">
            <div className="grid size-9 place-items-center rounded-full bg-linear-to-br from-ice to-sky text-xs font-extrabold text-navy">
              {initial}
            </div>
            <div className="min-w-0">
              <b className="block truncate text-[11px]">{name}</b>
              <small className="block truncate text-[8px] text-muted">{user.email}</small>
            </div>
          </div>
          <nav className="grid gap-1.5" aria-label="Ebolt navigation">
            {NAV.map((item) => {
              const Icon = item.icon;
              const active = page === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => (item.id === "new" ? useEbolt.getState().newNote() : go(item.id))}
                  className={cn(
                    "flex h-11 items-center gap-2.5 rounded-[13px] px-3 text-left text-[10px] font-bold tracking-[0.55px] text-muted transition",
                    active && "border border-sky/20 bg-sky/10 text-cream",
                  )}
                >
                  <span
                    className={cn(
                      "grid size-6 place-items-center rounded-lg bg-sky/10 text-sky",
                      active && "bg-linear-to-br from-sky-2 to-ice text-navy",
                    )}
                  >
                    <Icon className="size-3.5" />
                  </span>
                  {item.label}
                </button>
              );
            })}
          </nav>
          <div className="mt-auto px-1 text-[8px] leading-relaxed text-dim">
            BUILD • WRITE • IMPROVE
            <button
              className="mt-2 flex h-9 w-full items-center justify-center gap-2 rounded-[10px] border border-white/10 bg-white/5 text-[9px] font-bold tracking-wide text-muted"
              onClick={logout}
            >
              <LogOut className="size-3" /> LOG OUT
            </button>
          </div>
        </aside>

        <main className="min-w-0 pb-20 lg:pb-0">
          <div className="mx-auto max-w-[1400px] px-4 py-5 sm:px-8 sm:py-6">
            {page === "home" && <HomeView name={name} />}
            {page === "saved" && <SavedView />}
            {page === "new" && <EditorView />}
            {page === "chat" && <ChatView />}
          </div>
        </main>
      </div>

      <nav className="fixed inset-x-0 bottom-0 z-30 grid grid-cols-4 gap-1 border-t border-sky/15 bg-ink/95 p-2 backdrop-blur lg:hidden">
        {NAV.map((item) => {
          const Icon = item.icon;
          const active = page === item.id;
          return (
            <button
              key={item.id}
              onClick={() => (item.id === "new" ? useEbolt.getState().newNote() : go(item.id))}
              className={cn(
                "flex h-12 flex-col items-center justify-center gap-0.5 rounded-xl text-[8px] font-bold text-muted",
                active && "bg-sky/10 text-cream",
              )}
            >
              <Icon className="size-4" />
              {item.label}
            </button>
          );
        })}
      </nav>

      {toast && (
        <div className="fixed right-5 bottom-24 z-50 rounded-xl border border-sky/25 bg-navy px-4 py-3 text-[10px] font-semibold text-ice shadow-xl lg:bottom-6">
          {toast}
        </div>
      )}
    </div>
  );
}

function HomeView({ name }: { name: string }) {
  const go = useEbolt((s) => s.go);
  const saveNote = useEbolt((s) => s.saveNote);
  const draftTitle = useEbolt((s) => s.draftTitle);
  const draftText = useEbolt((s) => s.draftText);
  const setDraftTitle = useEbolt((s) => s.setDraftTitle);
  const setDraftText = useEbolt((s) => s.setDraftText);
  const notes = useEbolt((s) => s.notes);
  const now = useMemo(() => new Date(), []);
  const day = now.toLocaleDateString(undefined, { weekday: "long" });
  const date = now.toLocaleDateString(undefined, { day: "numeric", month: "long", year: "numeric" });

  return (
    <section className="page-in">
      <div className="mb-5 flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
        <div>
          <h2 className="text-[25px] tracking-tight">Hey, {name} 👋</h2>
          <p className="mt-1 text-[11px] text-dim italic">Let’s make progress today!</p>
        </div>
        <div className="flex min-w-[210px] items-center gap-3 rounded-2xl border border-sky/15 bg-navy/80 px-3 py-2.5">
          <Orb size={40} />
          <div className="text-right">
            <strong className="block text-[11px]">{day}</strong>
            <span className="mt-0.5 block text-[9px] text-muted">{date}</span>
          </div>
        </div>
      </div>

      <div className="hero-dots relative flex min-h-[360px] items-center justify-center overflow-hidden rounded-[28px] border border-sky/15 bg-linear-to-br from-navy/92 to-navy-2/85 text-center">
        <div className="relative z-2 max-w-[780px] px-5 py-10">
          <div className="mb-4 text-[9px] font-extrabold tracking-[2.8px] text-sky">BLACKBOX / EBOLT WORKSPACE</div>
          <h1 className="font-display text-[clamp(36px,5.6vw,64px)] leading-[1.08] font-semibold tracking-tight text-transparent bg-clip-text bg-linear-to-r from-cream via-sky to-ice">
            Explore your
            <br />
            ideas clearly.
          </h1>
          <p className="mx-auto mt-5 max-w-[650px] text-[12px] leading-7 text-muted">
            Your focused Blackbox workspace for writing, organizing, saving and improving ideas without the extra
            dashboard clutter.
          </p>
          <div className="mt-5 flex justify-center gap-2">
            <button className="pill pill-primary" onClick={() => useEbolt.getState().newNote()}>
              OPEN BLACKBOX
            </button>
            <button className="pill" onClick={() => go("saved")}>
              VIEW SAVED NOTES
            </button>
          </div>
        </div>
      </div>

      <div className="mt-7">
        <div className="mb-4 flex flex-col justify-between gap-3 sm:flex-row sm:items-end">
          <div>
            <h2 className="text-[19px]">Blackbox quick workspace</h2>
            <p className="mt-1 text-[9px] text-dim">Write directly from Home. {notes.length} saved notes.</p>
          </div>
          <div className="flex gap-2">
            <button className="pill" onClick={() => go("saved")}>
              Saved Note
            </button>
            <button className="pill pill-primary" onClick={() => useEbolt.getState().newNote()}>
              New
            </button>
          </div>
        </div>
        <div className="grid gap-3 lg:grid-cols-[minmax(0,1fr)_300px]">
          <div className="overflow-hidden rounded-[18px] border border-sky/20 bg-[#02080c]">
            <div className="flex h-11 items-center justify-between border-b border-sky/10 px-3">
              <div className="flex gap-1">
                <i className="size-1.5 rounded-full bg-dim" />
                <i className="size-1.5 rounded-full bg-dim" />
                <i className="size-1.5 rounded-full bg-dim" />
              </div>
              <input
                className="h-7 w-40 rounded-md border border-sky/20 bg-white/5 px-2 font-mono text-[9px] text-ice outline-none"
                value={draftTitle}
                onChange={(e) => setDraftTitle(e.target.value)}
                aria-label="Note title"
              />
              <button className="pill" onClick={saveNote}>
                Save
              </button>
            </div>
            <textarea
              className="min-h-[280px] w-full resize-none border-0 bg-transparent p-4 font-mono text-[12px] leading-7 text-ice outline-none"
              value={draftText}
              onChange={(e) => setDraftText(e.target.value)}
            />
          </div>
          <aside className="glass-card rounded-[18px] p-4">
            <h3 className="mb-3 text-[11px]">Blackbox quotes</h3>
            {["Build ideas into something real.", "Turn a rough idea into a clear task.", "Small steps create big progress.", "Write it, save it, improve it."].map(
              (q) => (
                <div key={q} className="border-b border-sky/10 py-3 font-mono text-[10px] text-dim">
                  <b className="text-sky">“</b> {q}
                </div>
              ),
            )}
          </aside>
        </div>
      </div>
    </section>
  );
}

function SavedView() {
  const notes = useEbolt((s) => s.notes);
  const loadNote = useEbolt((s) => s.loadNote);
  const deleteNote = useEbolt((s) => s.deleteNote);
  const newNote = useEbolt((s) => s.newNote);

  function onDelete(id: string, title: string) {
    if (!confirm(`Delete "${title}"? This cannot be undone.`)) return;
    deleteNote(id);
  }

  return (
    <section className="page-in">
      <div className="mb-4 flex flex-col justify-between gap-3 sm:flex-row sm:items-end">
        <div>
          <h2 className="text-[19px]">Saved Note</h2>
          <p className="mt-1 text-[9px] text-dim">Open, continue, edit and manage your saved Blackbox notes.</p>
        </div>
        <button className="pill pill-primary" onClick={newNote}>
          New note
        </button>
      </div>
      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
        {notes.map((n) => (
          <article
            key={n.id}
            className="glass-card relative min-h-[165px] cursor-pointer rounded-[18px] p-4 pr-12 transition hover:-translate-y-0.5 hover:border-sky/30"
            onClick={() => loadNote(n.id)}
          >
            <button
              type="button"
              className="absolute top-3 right-3 grid size-[30px] place-items-center rounded-[9px] border border-sky/20 bg-white/5 text-muted hover:border-danger/40 hover:bg-red-500/15 hover:text-danger"
              aria-label={`Delete ${n.title}`}
              onClick={(e) => {
                e.stopPropagation();
                onDelete(n.id, n.title);
              }}
            >
              <X className="size-3.5" />
            </button>
            <h3 className="mb-2 pr-4 text-[13px]">{n.title}</h3>
            <p className="line-clamp-4 text-[10px] leading-5 text-dim">{n.text || "Empty note"}</p>
            <div className="mt-4 flex items-center justify-between">
              <small className="text-[8px] text-dim">{n.updated}</small>
              <button
                type="button"
                className="pill inline-flex h-8 items-center gap-1"
                onClick={(e) => {
                  e.stopPropagation();
                  loadNote(n.id);
                }}
              >
                <Pencil className="size-3" /> Edit
              </button>
            </div>
          </article>
        ))}
        <button
          type="button"
          onClick={newNote}
          className="glass-card flex min-h-[165px] flex-col items-center justify-center gap-3 rounded-[18px] border-dashed border-sky/30 text-sky transition hover:border-sky/60 hover:bg-sky/5"
        >
          <span className="grid size-12 place-items-center rounded-full border border-sky/30 text-2xl">+</span>
          <span className="text-[11px] font-bold tracking-wide">New note</span>
        </button>
      </div>
    </section>
  );
}

function EditorView() {
  const currentNoteId = useEbolt((s) => s.currentNoteId);
  const draftTitle = useEbolt((s) => s.draftTitle);
  const draftText = useEbolt((s) => s.draftText);
  const setDraftTitle = useEbolt((s) => s.setDraftTitle);
  const setDraftText = useEbolt((s) => s.setDraftText);
  const saveNote = useEbolt((s) => s.saveNote);
  const newNote = useEbolt((s) => s.newNote);
  const renameDraft = useEbolt((s) => s.renameDraft);
  const go = useEbolt((s) => s.go);
  const editing = Boolean(currentNoteId);

  function rename() {
    const next = prompt("Name this note", draftTitle);
    if (next && next.trim()) renameDraft(next);
  }

  return (
    <section className="page-in">
      <div className="mb-4 flex flex-col justify-between gap-3 sm:flex-row sm:items-end">
        <div>
          <h2 className="text-[19px]">{editing ? "Edit note" : "New Blackbox"}</h2>
          <p className="mt-1 text-[9px] text-dim">
            {editing ? "Update this note and save. Delete from Saved Note." : "Create a new text, rename it and save it as a note."}
          </p>
        </div>
        <div className="flex gap-2">
          <button className="pill" onClick={newNote}>
            Clear
          </button>
          <button className="pill" onClick={() => go("saved")}>
            All notes
          </button>
          <button className="pill pill-primary" onClick={saveNote}>
            {editing ? "Update note" : "Save note"}
          </button>
        </div>
      </div>
      <div className="grid gap-3 lg:grid-cols-[1fr_280px]">
        <div className="glass-card rounded-[18px] p-4">
          <input
            className="mb-3 h-11 w-full rounded-xl border border-sky/20 bg-white/5 px-3.5 text-[12px] font-bold text-cream outline-none"
            value={draftTitle}
            onChange={(e) => setDraftTitle(e.target.value)}
            placeholder="Note title"
          />
          <textarea
            className="min-h-[380px] w-full resize-y rounded-xl border-0 bg-transparent p-2 font-mono text-[12px] leading-7 text-ice outline-none"
            value={draftText}
            onChange={(e) => setDraftText(e.target.value)}
          />
          <div className="mt-3 flex gap-2">
            <button className="pill" onClick={rename}>
              Rename
            </button>
            <button className="pill pill-primary" onClick={saveNote}>
              {editing ? "Update" : "Save"}
            </button>
          </div>
        </div>
        <aside className="glass-card rounded-[18px] p-4">
          <h3 className="mb-3 text-[12px]">Blackbox tools</h3>
          {[
            "Write without leaving the workspace.",
            "Rename the note whenever you need.",
            "Save many notes — each keeps its own id.",
            "Edit or delete any card from Saved Note.",
          ].map((t, i) => (
            <div key={t} className="border-b border-sky/10 py-3 text-[9px] text-muted">
              <b className="text-sky">0{i + 1}</b> {t}
            </div>
          ))}
        </aside>
      </div>
    </section>
  );
}

function ChatView() {
  const chat = useEbolt((s) => s.chat);
  const sendChat = useEbolt((s) => s.sendChat);
  const [value, setValue] = useState("");
  const box = useRef<HTMLDivElement>(null);

  useEffect(() => {
    box.current?.scrollTo({ top: box.current.scrollHeight });
  }, [chat.length]);

  function onSubmit(e: FormEvent) {
    e.preventDefault();
    sendChat(value);
    setValue("");
  }

  return (
    <section className="page-in">
      <div className="mb-4">
        <h2 className="text-[19px]">AI Chat Bot</h2>
        <p className="mt-1 text-[9px] text-dim">Ask the Ebolt assistant about your notes, ideas and workflow.</p>
      </div>
      <section className="glass-card flex min-h-[620px] flex-col overflow-hidden rounded-[20px]">
        <div className="flex items-center gap-3 border-b border-sky/10 px-4 py-4">
          <img src="/ebolt-logo.png" alt="" className="size-10 rounded-xl object-cover" />
          <div>
            <b className="text-[12px]">Ebolt AI Chat Bot</b>
            <span className="mt-1 block text-[8px] text-dim">Ready to help with your Blackbox workspace</span>
          </div>
        </div>
        <div ref={box} className="flex flex-1 flex-col gap-3 overflow-auto p-5">
          {chat.map((m, i) => (
            <div
              key={i}
              className={cn(
                "max-w-[75%] rounded-[15px] px-3.5 py-3 text-[10px] leading-5",
                m.role === "bot"
                  ? "self-start border border-sky/10 bg-sky/10 text-ice"
                  : "self-end bg-linear-to-r from-sky-2 to-ice text-navy",
              )}
            >
              {m.text}
            </div>
          ))}
        </div>
        <form className="flex gap-2 border-t border-sky/10 p-3" onSubmit={onSubmit}>
          <input
            className="h-10 flex-1 rounded-xl border border-sky/20 bg-white/5 px-3 text-cream outline-none"
            placeholder="Ask something about your workspace..."
            value={value}
            onChange={(e) => setValue(e.target.value)}
          />
          <button className="pill pill-primary h-10" type="submit">
            SEND
          </button>
        </form>
      </section>
    </section>
  );
}
