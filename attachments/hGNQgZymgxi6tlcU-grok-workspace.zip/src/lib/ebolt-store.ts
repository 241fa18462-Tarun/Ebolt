import { create } from "zustand";

export type EboltPage = "home" | "new" | "saved" | "chat";

export type Note = {
  id: string;
  title: string;
  text: string;
  updated: string;
};

export type Account = {
  email: string;
  password: string;
  fullName?: string;
};

type ChatMsg = { role: "user" | "bot"; text: string };

type State = {
  user: Account | null;
  page: EboltPage;
  notes: Note[];
  currentNoteId: string | null;
  draftTitle: string;
  draftText: string;
  toast: string | null;
  chat: ChatMsg[];
  login: (user: Account) => void;
  logout: () => void;
  go: (page: EboltPage) => void;
  setDraftTitle: (v: string) => void;
  setDraftText: (v: string) => void;
  newNote: () => void;
  saveNote: () => void;
  loadNote: (id: string) => void;
  deleteNote: (id: string) => void;
  renameDraft: (title: string) => void;
  showToast: (msg: string) => void;
  sendChat: (text: string) => void;
};

const NOTES_KEY = "ebolt_notes";
const REMEMBER_KEY = "ebolt_remember";
const ACCOUNTS_KEY = "ebolt_accounts";

function readNotes(): Note[] {
  try {
    const raw = JSON.parse(localStorage.getItem(NOTES_KEY) || "[]");
    if (!Array.isArray(raw)) return [];
    return raw.map((n: Note, i: number) => ({
      id: n.id || `legacy_${i}_${Date.now()}`,
      title: n.title || "Untitled note",
      text: n.text || "",
      updated: n.updated || new Date().toLocaleString(),
    }));
  } catch {
    return [];
  }
}

function writeNotes(notes: Note[]) {
  localStorage.setItem(NOTES_KEY, JSON.stringify(notes.slice(0, 80)));
}

export function readAccounts(): Record<string, Account> {
  try {
    return JSON.parse(localStorage.getItem(ACCOUNTS_KEY) || "{}") || {};
  } catch {
    return {};
  }
}

export function writeAccounts(accounts: Record<string, Account>) {
  localStorage.setItem(ACCOUNTS_KEY, JSON.stringify(accounts));
}

export function displayName(email: string, fullName?: string) {
  if (fullName?.trim()) return fullName.trim();
  return email
    .split("@")[0]
    .replace(/[._-]+/g, " ")
    .replace(/\b\w/g, (c) => c.toUpperCase());
}

let toastTimer: ReturnType<typeof setTimeout> | undefined;

export const useEbolt = create<State>((set, get) => ({
  user: null,
  page: "home",
  notes: typeof window === "undefined" ? [] : readNotes(),
  currentNoteId: null,
  draftTitle: "Untitled note",
  draftText: "Start writing your next idea...",
  toast: null,
  chat: [
    {
      role: "bot",
      text: "Hi! I’m your Ebolt AI Chat Bot. Tell me what you want to write, organize or improve.",
    },
  ],
  login: (user) => {
    set({
      user,
      page: "home",
      notes: readNotes(),
      currentNoteId: null,
      draftTitle: "Untitled note",
      draftText: "Start writing your next idea...",
    });
  },
  logout: () => {
    localStorage.removeItem(REMEMBER_KEY);
    set({
      user: null,
      page: "home",
      currentNoteId: null,
      draftTitle: "Untitled note",
      draftText: "Start writing your next idea...",
    });
  },
  go: (page) => set({ page }),
  setDraftTitle: (draftTitle) => set({ draftTitle }),
  setDraftText: (draftText) => set({ draftText }),
  newNote: () =>
    set({
      currentNoteId: null,
      draftTitle: "Untitled note",
      draftText:
        "Start writing here...\n\nAdd your development notes, ideas, commands or documentation.",
      page: "new",
    }),
  saveNote: () => {
    const { draftTitle, draftText, currentNoteId, notes } = get();
    const title = draftTitle.trim() || "Untitled note";
    const text = draftText.trim();
    const now = new Date().toLocaleString();
    let next = [...notes];
    let id = currentNoteId;
    if (id) {
      const idx = next.findIndex((n) => n.id === id);
      if (idx >= 0) {
        next[idx] = { ...next[idx], title, text, updated: now };
      } else {
        id = `note_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
        next.unshift({ id, title, text, updated: now });
      }
    } else {
      id = `note_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
      next.unshift({ id, title, text, updated: now });
    }
    writeNotes(next);
    set({ notes: next, currentNoteId: id, draftTitle: title, draftText: text || draftText });
    get().showToast("Note saved");
  },
  loadNote: (id) => {
    const n = get().notes.find((x) => x.id === id);
    if (!n) return;
    set({
      currentNoteId: n.id,
      draftTitle: n.title,
      draftText: n.text,
      page: "new",
    });
    get().showToast("Note opened");
  },
  deleteNote: (id) => {
    const { notes, currentNoteId } = get();
    const next = notes.filter((n) => n.id !== id);
    writeNotes(next);
    if (currentNoteId === id) {
      set({
        notes: next,
        currentNoteId: null,
        draftTitle: "Untitled note",
        draftText:
          "Start writing here...\n\nAdd your development notes, ideas, commands or documentation.",
      });
    } else {
      set({ notes: next });
    }
    get().showToast("Note deleted");
  },
  renameDraft: (title) => set({ draftTitle: title.trim() || "Untitled note" }),
  showToast: (msg) => {
    if (toastTimer) clearTimeout(toastTimer);
    set({ toast: msg });
    toastTimer = setTimeout(() => set({ toast: null }), 1800);
  },
  sendChat: (text) => {
    const trimmed = text.trim();
    if (!trimmed) return;
    const reply =
      "I can help you shape that idea. Try putting the main goal, the next action, and any important details into your Blackbox note.";
    set({
      chat: [
        ...get().chat,
        { role: "user", text: trimmed },
        { role: "bot", text: reply },
      ],
    });
  },
}));

export function tryRememberedUser(): Account | null {
  try {
    return JSON.parse(localStorage.getItem(REMEMBER_KEY) || "null");
  } catch {
    return null;
  }
}

export function rememberUser(user: Account) {
  localStorage.setItem(REMEMBER_KEY, JSON.stringify(user));
}
